import { User, FoodDonation, RecipientOrg, VolunteerBadge, ImpactStats } from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'user_donor_1',
    name: 'Suresh Kumar',
    email: 'suresh@grandroyale.org',
    phone: '+91 98450 12345',
    roles: ['donor'],
    activeRole: 'donor',
    organizationName: 'Grand Royale Wedding & Convention Hall',
    organizationType: 'wedding_hall',
    address: 'Plot 42, Outer Ring Road, Near Marathahalli Bridge',
    city: 'Bengaluru',
  },
  {
    id: 'user_donor_2',
    name: 'Chef Anita Menon',
    email: 'anita@spicegardens.com',
    phone: '+91 98765 43210',
    roles: ['donor'],
    activeRole: 'donor',
    organizationName: 'Spice Garden Fine Dining & Banquets',
    organizationType: 'restaurant',
    address: '88 100ft Road, Indiranagar',
    city: 'Bengaluru',
  },
  {
    id: 'user_recipient_1',
    name: 'Sister Mary Joseph',
    email: 'contact@snehahome.org',
    phone: '+91 94481 22334',
    roles: ['recipient'],
    activeRole: 'recipient',
    organizationName: 'Sneha Children Care & Orphanage',
    organizationType: 'orphanage',
    address: '14 St. Jude Lane, Ulsoor',
    city: 'Bengaluru',
    recipientCapacity: 45,
    dietaryPreference: 'veg',
    isVerifiedOrg: true,
  },
  {
    id: 'user_recipient_2',
    name: 'Dr. Ramesh Kulkarni',
    email: 'trustee@karunaelderly.org',
    phone: '+91 98200 88776',
    roles: ['recipient'],
    activeRole: 'recipient',
    organizationName: 'Karuna Senior Citizens Care Home',
    organizationType: 'old_age_home',
    address: '67 Green Glen Layout, Bellandur',
    city: 'Bengaluru',
    recipientCapacity: 60,
    dietaryPreference: 'veg',
    isVerifiedOrg: true,
  },
  {
    id: 'user_volunteer_1',
    name: 'Rahul Sharma',
    email: 'rahul.s@foodbridge.volunteer',
    phone: '+91 98111 22334',
    roles: ['volunteer', 'donor'], // Dual role!
    activeRole: 'volunteer',
    address: 'Sector 3, HSR Layout',
    city: 'Bengaluru',
    vehicleType: 'two_wheeler',
    volunteerPoints: 650,
    completedDeliveriesCount: 6,
    badges: ['badge_first_mile', 'badge_community_guardian', 'badge_lightning_speed', 'badge_feast_champion'],
  },
  {
    id: 'user_volunteer_2',
    name: 'Priya Deshmukh',
    email: 'priya.d@foodbridge.volunteer',
    phone: '+91 99001 55443',
    roles: ['volunteer'],
    activeRole: 'volunteer',
    address: 'Koramangala 4th Block',
    city: 'Bengaluru',
    vehicleType: 'car',
    volunteerPoints: 120,
    completedDeliveriesCount: 1,
    badges: ['badge_first_mile'],
  },
];

export const RECIPIENT_ORGS: RecipientOrg[] = [
  {
    id: 'rec_org_1',
    name: 'Sneha Children Care & Orphanage',
    type: 'orphanage',
    capacity: 45,
    currentNeed: 'Needs evening dinner for 45 children (ages 6-16). Prefers mild spice vegetarian.',
    dietaryPreference: 'veg',
    address: '14 St. Jude Lane, Ulsoor, Bengaluru',
    contactPerson: 'Sister Mary Joseph',
    phone: '+91 94481 22334',
    distanceKm: 3.4,
    verified: true,
  },
  {
    id: 'rec_org_2',
    name: 'Karuna Senior Citizens Care Home',
    type: 'old_age_home',
    capacity: 60,
    currentNeed: 'Requires soft cooked rice, dal, and vegetable stew for 60 elderly residents.',
    dietaryPreference: 'veg',
    address: '67 Green Glen Layout, Bellandur, Bengaluru',
    contactPerson: 'Dr. Ramesh Kulkarni',
    phone: '+91 98200 88776',
    distanceKm: 4.8,
    verified: true,
  },
  {
    id: 'rec_org_3',
    name: 'Asha Deep Homeless Night Shelter',
    type: 'homeless_shelter',
    capacity: 80,
    currentNeed: 'High requirement: 80 daily wage laborers & homeless individuals seeking evening meal.',
    dietaryPreference: 'all',
    address: 'Under Shivaji Nagar Flyover, Russell Market Area',
    contactPerson: 'Imran Baig',
    phone: '+91 97400 33211',
    distanceKm: 6.2,
    verified: true,
  },
  {
    id: 'rec_org_4',
    name: 'Jyothi Blind & Special Needs Children Home',
    type: 'orphanage',
    capacity: 35,
    currentNeed: 'Fresh nutritious meals, rotis, rice, and fruit for 35 visually impaired children.',
    dietaryPreference: 'veg',
    address: '22 Gandhi Bazaar Main Road, Basavanagudi',
    contactPerson: 'Smt. Lakshmi Devi',
    phone: '+91 94801 11223',
    distanceKm: 7.5,
    verified: true,
  },
];

export const ALL_BADGES: VolunteerBadge[] = [
  {
    id: 'badge_first_mile',
    name: 'First Mile Hero',
    description: 'Completed your very first verified food rescue delivery mission.',
    iconName: 'Award',
    tier: 'bronze',
  },
  {
    id: 'badge_community_guardian',
    name: 'Community Guardian',
    description: 'Successfully rescued and delivered over 5 food donations.',
    iconName: 'ShieldCheck',
    tier: 'silver',
  },
  {
    id: 'badge_lightning_speed',
    name: 'Lightning Responder',
    description: 'Picked up hot banquet food within 35 minutes of alert.',
    iconName: 'Zap',
    tier: 'silver',
  },
  {
    id: 'badge_feast_champion',
    name: 'Feast Champion',
    description: 'Delivered 75+ meals in a single coordinated run to a large shelter.',
    iconName: 'HeartHandshake',
    tier: 'gold',
  },
  {
    id: 'badge_night_watch',
    name: 'Night Watch Angel',
    description: 'Collected late-night wedding hall surplus between 9:00 PM and midnight.',
    iconName: 'Moon',
    tier: 'gold',
  },
  {
    id: 'badge_centurion',
    name: 'Centurion Rescuer',
    description: 'Delivered more than 500 total meals across verified missions.',
    iconName: 'Crown',
    tier: 'platinum',
  },
];

export const INITIAL_DONATIONS: FoodDonation[] = [
  {
    id: 'don_101',
    foodName: 'Wedding Feast: Veg Pulao, Paneer Butter Masala, Mixed Veg Curry & 120 Chapattis',
    category: 'wedding_banquet',
    dietType: 'veg',
    quantityServings: 90,
    estimatedWeightKg: 42,
    numberOfContainers: 4,
    description: 'Surplus from afternoon wedding reception. Freshly packed in clean stainless steel catering containers. Kept heated in chafing trays until 2:30 PM.',
    prepTime: '2:00 PM Today (1.5 hrs ago)',
    prepTimeHoursAgo: 1.5,
    availableUntil: '7:30 PM Today',
    storageCondition: 'hot_maintained',
    packaging: 'sealed_steel_containers',
    donorId: 'user_donor_1',
    donorName: 'Suresh Kumar',
    donorOrg: 'Grand Royale Wedding & Convention Hall',
    donorPhone: '+91 98450 12345',
    pickupAddress: 'Grand Royale Hall, Gate 2 Loading Dock, Outer Ring Road',
    pickupLandmark: 'Opposite Cisco Tech Park, Marathahalli',
    pickupCity: 'Bengaluru',
    pickupPinCode: '560037',
    status: 'available',
    createdAt: new Date(Date.now() - 90 * 60 * 1000).toISOString(),
    isSafetyApproved: true,
    safetyScore: 94,
    safetyNotes: 'Food temperature checked at 68°C. Packed in sanitized food-grade stainless steel containers.',
    allergenInfo: 'Contains dairy (paneer) and cashew paste.',
    pickupVerificationCode: '4821',
    deliveryVerificationCode: '9153',
  },
  {
    id: 'don_102',
    foodName: 'Buffet Surplus: Jeera Rice, Dal Tadka, Gobi Manchurian & Fresh Cut Fruits',
    category: 'hotel_buffet',
    dietType: 'veg',
    quantityServings: 45,
    estimatedWeightKg: 20,
    numberOfContainers: 3,
    description: 'Lunch buffet surplus. Untouched serving counter trays transferred into disposable foil food containers with sealed lids.',
    prepTime: '1:30 PM Today (2 hrs ago)',
    prepTimeHoursAgo: 2,
    availableUntil: '6:00 PM Today',
    storageCondition: 'room_temp_ambient',
    packaging: 'foil_packed_boxes',
    donorId: 'user_donor_2',
    donorName: 'Chef Anita Menon',
    donorOrg: 'Spice Garden Fine Dining & Banquets',
    donorPhone: '+91 98765 43210',
    pickupAddress: 'Spice Garden Restaurant, Kitchen Rear Exit, 88 100ft Road',
    pickupLandmark: 'Near Sony Center, Indiranagar',
    pickupCity: 'Bengaluru',
    pickupPinCode: '560038',
    status: 'requested',
    createdAt: new Date(Date.now() - 120 * 60 * 1000).toISOString(),
    isSafetyApproved: true,
    safetyScore: 88,
    safetyNotes: 'Safe for prompt transport. Recommend delivery within 2 hours.',
    requestedByRecipientId: 'rec_org_1',
    requestedByRecipientName: 'Sneha Children Care & Orphanage',
    recipientAddress: '14 St. Jude Lane, Ulsoor, Bengaluru',
    recipientContact: 'Sister Mary Joseph (+91 94481 22334)',
    pickupVerificationCode: '7319',
    deliveryVerificationCode: '6204',
  },
  {
    id: 'don_103',
    foodName: 'Corporate Gala Dinner: Chicken Biryani & Egg Curry',
    category: 'event_surplus',
    dietType: 'non_veg',
    quantityServings: 65,
    estimatedWeightKg: 30,
    numberOfContainers: 3,
    description: 'Corporate annual dinner surplus. High quality non-veg meal, stored in insulated hot cases.',
    prepTime: '12:45 PM Today (2.5 hrs ago)',
    prepTimeHoursAgo: 2.5,
    availableUntil: '5:30 PM Today',
    storageCondition: 'hot_maintained',
    packaging: 'foil_packed_boxes',
    donorId: 'user_donor_1',
    donorName: 'Suresh Kumar',
    donorOrg: 'Grand Royale Wedding & Convention Hall',
    donorPhone: '+91 98450 12345',
    pickupAddress: 'Gate 2 Loading Bay, Outer Ring Road',
    pickupLandmark: 'Opposite Cisco Tech Park',
    pickupCity: 'Bengaluru',
    pickupPinCode: '560037',
    status: 'accepted',
    createdAt: new Date(Date.now() - 150 * 60 * 1000).toISOString(),
    isSafetyApproved: true,
    safetyScore: 91,
    safetyNotes: 'Non-veg items thoroughly cooked, internal temperature above 74°C when insulated.',
    requestedByRecipientId: 'rec_org_3',
    requestedByRecipientName: 'Asha Deep Homeless Night Shelter',
    recipientAddress: 'Under Shivaji Nagar Flyover, Russell Market Area',
    recipientContact: 'Imran Baig (+91 97400 33211)',
    assignedVolunteerId: 'user_volunteer_1',
    assignedVolunteerName: 'Rahul Sharma',
    assignedVolunteerPhone: '+91 98111 22334',
    pickupVerificationCode: '2984',
    deliveryVerificationCode: '5412',
  },
  {
    id: 'don_104',
    foodName: 'Temple Festival Prasad: Sweet Pongal & Curd Rice',
    category: 'event_surplus',
    dietType: 'veg',
    quantityServings: 110,
    estimatedWeightKg: 50,
    numberOfContainers: 5,
    description: 'Sacred festive offering. Prepared with pure cow ghee and jaggery in traditional brass containers.',
    prepTime: '10:00 AM Today',
    prepTimeHoursAgo: 5,
    availableUntil: 'Completed at 1:15 PM',
    storageCondition: 'refrigerated',
    packaging: 'sealed_steel_containers',
    donorId: 'user_donor_1',
    donorName: 'Suresh Kumar',
    donorOrg: 'Grand Royale Wedding & Convention Hall',
    donorPhone: '+91 98450 12345',
    pickupAddress: 'Grand Royale Banquet Kitchen',
    pickupLandmark: 'Outer Ring Road, Marathahalli',
    pickupCity: 'Bengaluru',
    pickupPinCode: '560037',
    status: 'delivered',
    createdAt: new Date(Date.now() - 300 * 60 * 1000).toISOString(),
    isSafetyApproved: true,
    safetyScore: 98,
    requestedByRecipientId: 'rec_org_2',
    requestedByRecipientName: 'Karuna Senior Citizens Care Home',
    recipientAddress: '67 Green Glen Layout, Bellandur',
    recipientContact: 'Dr. Ramesh Kulkarni (+91 98200 88776)',
    assignedVolunteerId: 'user_volunteer_1',
    assignedVolunteerName: 'Rahul Sharma',
    assignedVolunteerPhone: '+91 98111 22334',
    pickupVerificationCode: '1102',
    deliveryVerificationCode: '8843',
    pickedUpAt: '12:30 PM Today',
    deliveredAt: '1:15 PM Today',
    deliveryNotes: 'Warmly received by Dr. Ramesh. All 60 elderly residents enjoyed fresh prasad.',
  },
];

export const INITIAL_IMPACT_STATS: ImpactStats = {
  mealsDelivered: 4320,
  kgRescued: 1890,
  completedDeliveries: 187,
  activeVolunteers: 76,
  careHomesSupported: 29,
  co2SavedKg: 4725,
};

const STORAGE_KEYS = {
  USERS: 'foodbridge_users_v1',
  CURRENT_USER: 'foodbridge_current_user_v1',
  DONATIONS: 'foodbridge_donations_v1',
  RECIPIENTS: 'foodbridge_recipients_v1',
  IMPACT: 'foodbridge_impact_v1',
};

export function getStoredUsers(): User[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USERS);
    if (raw) return JSON.parse(raw);
  } catch {}
  return INITIAL_USERS;
}

export function saveUsers(users: User[]): void {
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
}

export function getStoredCurrentUser(): User {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (raw) return JSON.parse(raw);
  } catch {}
  return INITIAL_USERS[4]; // Default to Rahul Sharma (Volunteer & Donor) for immediate rich exploration
}

export function saveCurrentUser(user: User): void {
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
}

export function getStoredDonations(): FoodDonation[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DONATIONS);
    if (raw) return JSON.parse(raw);
  } catch {}
  return INITIAL_DONATIONS;
}

export function saveDonations(donations: FoodDonation[]): void {
  localStorage.setItem(STORAGE_KEYS.DONATIONS, JSON.stringify(donations));
}

export function getStoredRecipients(): RecipientOrg[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RECIPIENTS);
    if (raw) return JSON.parse(raw);
  } catch {}
  return RECIPIENT_ORGS;
}

export function saveRecipients(recipients: RecipientOrg[]): void {
  localStorage.setItem(STORAGE_KEYS.RECIPIENTS, JSON.stringify(recipients));
}

export function getStoredImpact(): ImpactStats {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.IMPACT);
    if (raw) return JSON.parse(raw);
  } catch {}
  return INITIAL_IMPACT_STATS;
}

export function saveImpact(impact: ImpactStats): void {
  localStorage.setItem(STORAGE_KEYS.IMPACT, JSON.stringify(impact));
}

export function resetAllToDefaults(): void {
  localStorage.removeItem(STORAGE_KEYS.USERS);
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  localStorage.removeItem(STORAGE_KEYS.DONATIONS);
  localStorage.removeItem(STORAGE_KEYS.RECIPIENTS);
  localStorage.removeItem(STORAGE_KEYS.IMPACT);
}
