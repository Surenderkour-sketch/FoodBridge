import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import {
  Users,
  Building2,
  Bike,
  Heart,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';

export const AuthPage: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const { currentUser, users, switchPersona, registerUser, showToast } = useApp();

  const [mode, setMode] = useState<'login' | 'register'>('login');

  // Registration Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Bengaluru');
  const [selectedRoles, setSelectedRoles] = useState<UserRole[]>(['volunteer']);
  const [orgName, setOrgName] = useState('');
  const [orgType, setOrgType] = useState<any>('wedding_hall');
  const [vehicleType, setVehicleType] = useState<any>('two_wheeler');
  const [recipientCapacity, setRecipientCapacity] = useState('50');
  const [dietPref, setDietPref] = useState<any>('veg');

  const toggleRole = (role: UserRole) => {
    if (selectedRoles.includes(role)) {
      if (selectedRoles.length === 1) {
        showToast('You must select at least one role.', 'warning');
        return;
      }
      setSelectedRoles(selectedRoles.filter((r) => r !== role));
    } else {
      setSelectedRoles([...selectedRoles, role]);
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast('Please enter your full name.', 'error');
      return;
    }
    if (!phone.trim()) {
      showToast('Please provide a contact phone number.', 'error');
      return;
    }

    const newUser = registerUser({
      name,
      email: email || `${name.toLowerCase().replace(/\s+/g, '')}@foodbridge.demo`,
      phone,
      address: address || 'Main City Area',
      city,
      roles: selectedRoles,
      activeRole: selectedRoles[0],
      organizationName: orgName || (selectedRoles.includes('donor') ? `${name}'s Kitchen` : undefined),
      organizationType: orgType,
      vehicleType,
      recipientCapacity: Number(recipientCapacity) || 40,
      dietaryPreference: dietPref,
    });

    // Auto navigate according to registered role
    if (newUser.activeRole === 'donor') onNavigate('donate');
    else if (newUser.activeRole === 'recipient') onNavigate('available');
    else onNavigate('volunteer');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-12">
      {/* Header */}
      <div className="text-center max-w-xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-2">
          <UserCheck className="w-3.5 h-3.5" />
          <span>Community Authentication</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">
          Join or Switch FoodBridge Account
        </h1>
        <p className="text-slate-400 text-xs sm:text-sm mt-1">
          Open to marriage halls, restaurants, orphanages, care homes, and any willing community volunteer.
        </p>
      </div>

      {/* Preset Accounts for Judges (Instant 1-Click) */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-700 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              <span>Demo Quick-Login (For Evaluation)</span>
            </span>
            <p className="text-xs text-slate-400 mt-0.5">
              Click any profile below to login instantly as that verified user.
            </p>
          </div>
          <div className="text-xs text-slate-400">
            Current: <strong className="text-emerald-400">{currentUser.name}</strong> ({currentUser.activeRole})
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {users.map((u) => {
            const isSelected = currentUser.id === u.id;
            const isDonor = u.roles.includes('donor');
            const isRecipient = u.roles.includes('recipient');
            const isVolunteer = u.roles.includes('volunteer');

            return (
              <div
                key={u.id}
                onClick={() => switchPersona(u.id)}
                className={`p-3.5 rounded-2xl border cursor-pointer transition text-left flex flex-col justify-between ${
                  isSelected
                    ? 'bg-emerald-950/40 border-emerald-500 shadow-md ring-1 ring-emerald-500'
                    : 'bg-slate-800/60 border-slate-700/80 hover:border-slate-600 hover:bg-slate-800'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-white truncate">{u.name}</span>
                    {isSelected && (
                      <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold">
                        Logged In
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">
                    {u.organizationName || u.address}
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-700/50 flex items-center justify-between text-[10px]">
                  <div className="flex gap-1">
                    {isDonor && (
                      <span className="px-1.5 py-0.5 rounded bg-emerald-900/60 text-emerald-300 border border-emerald-800">
                        Donor
                      </span>
                    )}
                    {isRecipient && (
                      <span className="px-1.5 py-0.5 rounded bg-teal-900/60 text-teal-300 border border-teal-800">
                        Care Home
                      </span>
                    )}
                    {isVolunteer && (
                      <span className="px-1.5 py-0.5 rounded bg-amber-900/60 text-amber-300 border border-amber-800">
                        Volunteer
                      </span>
                    )}
                  </div>
                  <span className="text-slate-400 font-medium">1-Click Login →</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Mode Switcher */}
      <div className="flex justify-center">
        <div className="inline-flex bg-slate-900 p-1 rounded-2xl border border-slate-800 text-xs font-semibold">
          <button
            onClick={() => setMode('login')}
            className={`px-6 py-2 rounded-xl transition ${
              mode === 'login' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Active Account Details
          </button>
          <button
            onClick={() => setMode('register')}
            className={`px-6 py-2 rounded-xl transition ${
              mode === 'register' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Register New Account
          </button>
        </div>
      </div>

      {/* Mode 1: Active Account Details */}
      {mode === 'login' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 max-w-2xl mx-auto space-y-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white font-extrabold text-2xl shadow-lg">
              {currentUser.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">{currentUser.name}</h3>
              <p className="text-xs text-slate-400">{currentUser.email} • {currentUser.phone}</p>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {currentUser.roles.map((r) => (
                  <span
                    key={r}
                    className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-800 text-emerald-400 border border-slate-700"
                  >
                    Role: {r}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-4 border-t border-slate-800">
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
              <span className="text-slate-400">Organization / Home:</span>
              <p className="font-semibold text-white mt-0.5">
                {currentUser.organizationName || 'Private Individual / Volunteer'}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
              <span className="text-slate-400">Location Base:</span>
              <p className="font-semibold text-white mt-0.5">
                {currentUser.address}, {currentUser.city}
              </p>
            </div>
            {currentUser.roles.includes('volunteer') && (
              <>
                <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
                  <span className="text-slate-400">Deliveries Completed:</span>
                  <p className="font-semibold text-emerald-400 mt-0.5">
                    {currentUser.completedDeliveriesCount || 0} missions verified
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
                  <span className="text-slate-400">Volunteer Points:</span>
                  <p className="font-semibold text-amber-400 mt-0.5">
                    {currentUser.volunteerPoints || 0} pts
                  </p>
                </div>
              </>
            )}
            {currentUser.roles.includes('recipient') && (
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 sm:col-span-2">
                <span className="text-slate-400">Beneficiary Capacity:</span>
                <p className="font-semibold text-teal-400 mt-0.5">
                  {currentUser.recipientCapacity || 50} residents supported • {currentUser.dietaryPreference?.toUpperCase()} diet
                </p>
              </div>
            )}
          </div>

          <div className="pt-2 flex flex-wrap gap-3">
            {currentUser.roles.includes('donor') && (
              <button
                onClick={() => onNavigate('donate')}
                className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition text-center"
              >
                Go to Donate Food →
              </button>
            )}
            {currentUser.roles.includes('recipient') && (
              <button
                onClick={() => onNavigate('available')}
                className="flex-1 py-2.5 px-4 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs transition text-center"
              >
                Go to Available Food →
              </button>
            )}
            {currentUser.roles.includes('volunteer') && (
              <button
                onClick={() => onNavigate('volunteer')}
                className="flex-1 py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs transition text-center"
              >
                Go to Volunteer Hub →
              </button>
            )}
          </div>
        </div>
      )}

      {/* Mode 2: Custom Registration Form */}
      {mode === 'register' && (
        <form
          onSubmit={handleRegisterSubmit}
          className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 max-w-2xl mx-auto space-y-6 shadow-2xl"
        >
          <div>
            <h3 className="text-lg font-bold text-white">Create Your Account</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Select one or more roles. You can be both a Food Donor and a Delivery Volunteer!
            </p>
          </div>

          {/* Role Multi-select Pills */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-300">
              Select Your Role(s) <span className="text-rose-400">*</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Donor */}
              <div
                onClick={() => toggleRole('donor')}
                className={`p-3 rounded-2xl border cursor-pointer transition text-left ${
                  selectedRoles.includes('donor')
                    ? 'bg-emerald-950/60 border-emerald-500 ring-1 ring-emerald-500'
                    : 'bg-slate-800/40 border-slate-700/80 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">Food Donor</span>
                  {selectedRoles.includes('donor') && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  )}
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Wedding hall, hotel, caterer, or home with surplus food.
                </p>
              </div>

              {/* Recipient */}
              <div
                onClick={() => toggleRole('recipient')}
                className={`p-3 rounded-2xl border cursor-pointer transition text-left ${
                  selectedRoles.includes('recipient')
                    ? 'bg-teal-950/60 border-teal-500 ring-1 ring-teal-500'
                    : 'bg-slate-800/40 border-slate-700/80 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">Food Recipient</span>
                  {selectedRoles.includes('recipient') && (
                    <CheckCircle2 className="w-4 h-4 text-teal-400" />
                  )}
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Orphanage, elder home, shelter serving hungry people.
                </p>
              </div>

              {/* Volunteer */}
              <div
                onClick={() => toggleRole('volunteer')}
                className={`p-3 rounded-2xl border cursor-pointer transition text-left ${
                  selectedRoles.includes('volunteer')
                    ? 'bg-amber-950/60 border-amber-500 ring-1 ring-amber-500'
                    : 'bg-slate-800/40 border-slate-700/80 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">Volunteer</span>
                  {selectedRoles.includes('volunteer') && (
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                  )}
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Willing citizen ready to collect and deliver meals.
                </p>
              </div>
            </div>
            {selectedRoles.includes('donor') && selectedRoles.includes('volunteer') && (
              <p className="text-[11px] text-amber-300 flex items-center gap-1.5 pt-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Dual Role enabled! You can donate food and deliver whenever available.</span>
              </p>
            )}
          </div>

          {/* Basic Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Full Name / Contact Person <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Ramesh Verma"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Phone Number <span className="text-rose-400">*</span>
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.org"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                City / Region
              </label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Bengaluru"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Conditional: Organization / Address Details */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Address / Area / Landmark
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. 45 Outer Ring Road, Near Bellandur"
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Conditional if Donor or Recipient */}
          {(selectedRoles.includes('donor') || selectedRoles.includes('recipient')) && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-800/40 border border-slate-800">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Organization / Facility Name
                </label>
                <input
                  type="text"
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                  placeholder={
                    selectedRoles.includes('donor')
                      ? 'e.g. Royal Palace Marriage Hall'
                      : 'e.g. Anand Orphanage'
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Facility Category
                </label>
                <select
                  value={orgType}
                  onChange={(e) => setOrgType(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                >
                  <option value="wedding_hall">Marriage / Convention Hall</option>
                  <option value="hotel">Hotel / Banquet</option>
                  <option value="restaurant">Restaurant / Caterer</option>
                  <option value="orphanage">Children Orphanage</option>
                  <option value="old_age_home">Senior Citizens / Old Age Home</option>
                  <option value="homeless_shelter">Homeless Shelter</option>
                  <option value="individual">Home / Individual</option>
                </select>
              </div>
            </div>
          )}

          {/* Conditional if Volunteer */}
          {selectedRoles.includes('volunteer') && (
            <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-800">
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Delivery Vehicle Type
              </label>
              <select
                value={vehicleType}
                onChange={(e) => setVehicleType(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              >
                <option value="two_wheeler">Two-Wheeler (Motorbike / Scooter)</option>
                <option value="car">Car / Hatchback</option>
                <option value="auto_rickshaw">Auto-Rickshaw</option>
                <option value="bicycle">Bicycle</option>
                <option value="van">Van / Small Commercial Tempo</option>
              </select>
              <p className="text-[10px] text-slate-400 mt-1">
                Any willing registered citizen can volunteer. No commercial driver license required for local food runs.
              </p>
            </div>
          )}

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm transition shadow-lg shadow-emerald-500/20"
          >
            Complete Registration & Start
          </button>
        </form>
      )}
    </div>
  );
};
