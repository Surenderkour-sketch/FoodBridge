import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { requestImpactSummary, ImpactSummaryResult } from '../services/geminiService';
import {
  BarChart3,
  UtensilsCrossed,
  Sparkles,
  TreePine,
  Heart,
  Bike,
  Building2,
  Users,
  CheckCircle2,
  Share2,
  Loader2,
  TrendingUp,
} from 'lucide-react';

export const ImpactDashboardPage: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const { impactStats, donations, showToast } = useApp();

  const [isGenerating, setIsGenerating] = useState(false);
  const [aiReport, setAiReport] = useState<ImpactSummaryResult | null>(null);

  // Auto load initial AI summary or allow manual regeneration
  useEffect(() => {
    let isMounted = true;
    async function loadInitial() {
      setIsGenerating(true);
      try {
        const report = await requestImpactSummary(impactStats);
        if (isMounted) setAiReport(report);
      } catch (err) {
        console.warn(err);
      } finally {
        if (isMounted) setIsGenerating(false);
      }
    }
    loadInitial();
    return () => {
      isMounted = false;
    };
  }, []);

  const handleRegenerateAi = async () => {
    setIsGenerating(true);
    try {
      const res = await requestImpactSummary(impactStats);
      setAiReport(res);
      showToast('Generated fresh Gemini AI Community Impact narrative report.', 'success');
    } catch {
      showToast('Loaded heuristic impact summary.', 'info');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'FoodBridge Community Impact',
        text: `FoodBridge has delivered ${impactStats.mealsDelivered.toLocaleString()} meals and saved ${impactStats.kgRescued.toLocaleString()} kg of banquet food!`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(
        `FoodBridge Impact: ${impactStats.mealsDelivered.toLocaleString()} meals delivered, ${impactStats.kgRescued.toLocaleString()} kg food rescued!`
      );
      showToast('Impact metrics copied to clipboard!', 'success');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-12">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Community Transparency & Carbon Impact</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Impact Dashboard
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">
            Measuring every plate rescued, every shelter nourished, and greenhouse gases prevented.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRegenerateAi}
            disabled={isGenerating}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-emerald-300 text-xs font-semibold transition flex items-center gap-1.5"
          >
            {isGenerating ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            )}
            <span>Regenerate AI Report</span>
          </button>

          <button
            onClick={handleShare}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition flex items-center gap-1.5"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Share Impact</span>
          </button>
        </div>
      </div>

      {/* Primary 4 Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Meals */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 relative overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3">
            <UtensilsCrossed className="w-5 h-5" />
          </div>
          <div className="text-3xl sm:text-4xl font-black text-white">
            {impactStats.mealsDelivered.toLocaleString()}
          </div>
          <div className="text-xs font-bold text-emerald-400 mt-1 uppercase tracking-wider">
            Meals Delivered
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Warm meals served across orphanages & elder homes
          </p>
        </div>

        {/* Kg Rescued */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 relative overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-3">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div className="text-3xl sm:text-4xl font-black text-white">
            {impactStats.kgRescued.toLocaleString()} kg
          </div>
          <div className="text-xs font-bold text-amber-400 mt-1 uppercase tracking-wider">
            Donations Rescued
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Diverted from garbage dumping sites
          </p>
        </div>

        {/* Completed Deliveries */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 relative overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center mb-3">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div className="text-3xl sm:text-4xl font-black text-white">
            {impactStats.completedDeliveries}
          </div>
          <div className="text-xs font-bold text-teal-400 mt-1 uppercase tracking-wider">
            Completed Deliveries
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            100% verified receiver code handovers
          </p>
        </div>

        {/* Active Volunteers */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 relative overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center mb-3">
            <Users className="w-5 h-5" />
          </div>
          <div className="text-3xl sm:text-4xl font-black text-white">
            {impactStats.activeVolunteers}
          </div>
          <div className="text-xs font-bold text-rose-400 mt-1 uppercase tracking-wider">
            Active Volunteers
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Selfless couriers with zero platform fees
          </p>
        </div>
      </div>

      {/* Gemini AI Community Impact Narrative Report */}
      <section className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-950/50 via-slate-900 to-teal-950/50 border border-emerald-500/40 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-emerald-900/40 pb-3">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>Gemini AI Community Impact Briefing</span>
          </div>
          <span className="text-[10px] font-mono text-emerald-300/80 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
            Powered by gemini-3.8-flash
          </span>
        </div>

        {isGenerating && !aiReport ? (
          <div className="flex items-center gap-3 py-6 text-xs text-slate-400">
            <Loader2 className="w-5 h-5 animate-spin text-emerald-400" />
            <span>Analyzing rescue data and synthesizing community report...</span>
          </div>
        ) : aiReport ? (
          <div className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-white">
              "{aiReport.headline}"
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              {aiReport.summary}
            </p>

            <blockquote className="p-3.5 rounded-2xl bg-slate-900/80 border-l-4 border-amber-400 text-xs italic text-amber-200">
              {aiReport.socialQuote}
            </blockquote>

            <div className="p-3.5 rounded-2xl bg-emerald-900/30 border border-emerald-800/60 text-xs text-emerald-300 flex items-start gap-2.5">
              <TreePine className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong>Environmental Footprint Offset:</strong> {aiReport.environmentalImpactText}
              </div>
            </div>
          </div>
        ) : null}
      </section>

      {/* Breakdown Charts / Distributions */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Donor Source Breakdown */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-400" />
            <span>Surplus Rescued by Donor Facility</span>
          </h3>

          <div className="space-y-3 pt-2">
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-300">Wedding & Convention Halls</span>
                <span className="text-emerald-400">48% (907 kg)</span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: '48%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-300">Hotels & Banquet Buffets</span>
                <span className="text-teal-400">28% (529 kg)</span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-teal-500 rounded-full" style={{ width: '28%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-300">Restaurants & Caterers</span>
                <span className="text-amber-400">16% (302 kg)</span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-amber-500 rounded-full" style={{ width: '16%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-300">Homes & Family Functions</span>
                <span className="text-cyan-400">8% (151 kg)</span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-cyan-500 rounded-full" style={{ width: '8%' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Beneficiaries Breakdown */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <Heart className="w-4 h-4 text-rose-400" />
            <span>Beneficiary Care Home Distribution</span>
          </h3>

          <div className="space-y-3 pt-2">
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-300">Children Care & Orphanages</span>
                <span className="text-rose-400">52% (2,246 meals)</span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-rose-500 rounded-full" style={{ width: '52%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-300">Elderly & Senior Citizens Homes</span>
                <span className="text-amber-400">33% (1,425 meals)</span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-amber-500 rounded-full" style={{ width: '33%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-300">Homeless Night Shelters</span>
                <span className="text-teal-400">15% (648 meals)</span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-teal-500 rounded-full" style={{ width: '15%' }} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Recent Rescues Feed */}
      <section className="space-y-4">
        <h3 className="font-bold text-white text-base">Verified Rescues Ledger</h3>
        <div className="space-y-2.5">
          {donations
            .filter((d) => d.status === 'delivered')
            .slice(0, 5)
            .map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-bold text-white text-sm">{item.foodName}</div>
                  <div className="text-slate-400 mt-0.5">
                    Rescued from <strong>{item.donorOrg}</strong> → Delivered to{' '}
                    <strong className="text-emerald-400">{item.requestedByRecipientName}</strong>
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold">
                    {item.quantityServings} Meals Fed
                  </span>
                  <span className="text-slate-500 font-mono">{item.deliveredAt || 'Today'}</span>
                </div>
              </div>
            ))}
        </div>
      </section>
    </div>
  );
};
