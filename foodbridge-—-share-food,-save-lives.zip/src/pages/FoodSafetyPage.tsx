import React, { useState } from 'react';
import { requestHandlingReminders, HandlingRemindersResult } from '../services/geminiService';
import {
  ShieldAlert,
  ShieldCheck,
  Thermometer,
  Clock,
  Sparkles,
  AlertTriangle,
  Package,
  CheckCircle2,
  XCircle,
  Loader2,
  Bike,
  UtensilsCrossed,
} from 'lucide-react';

export const FoodSafetyPage: React.FC = () => {
  // AI Handling Generator state
  const [foodItem, setFoodItem] = useState('Wedding Veg Biryani & Paneer Gravy');
  const [foodType, setFoodType] = useState('wedding_banquet');
  const [quantity, setQuantity] = useState('75 meals');
  const [transitMode, setTransitMode] = useState('Two-Wheeler with insulated delivery bag');
  const [isLoading, setIsLoading] = useState(false);
  const [aiReminders, setAiReminders] = useState<HandlingRemindersResult | null>(null);

  const handleGenerateReminders = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const res = await requestHandlingReminders({
        foodName: foodItem,
        foodType,
        quantity,
        transitMode,
      });
      setAiReminders(res);
    } catch (err) {
      console.warn(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-12">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/10 text-rose-400 text-xs font-semibold uppercase tracking-wider mb-2">
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Zero Compromise Food Safety Protocol</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Food Safety & Hygiene Standard
        </h1>
        <p className="text-slate-400 text-xs sm:text-sm mt-2 leading-relaxed">
          The beneficiaries of FoodBridge include vulnerable young children in orphanages and elderly residents in care homes.
          We enforce rigorous safety barriers: <strong>compromised or spoiled food is strictly rejected</strong> rather than recommended for delivery.
        </p>
      </div>

      {/* The 4 Cardinal Pillars of Food Safety */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Pillar 1: Time Window */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">
            1. The 4-Hour Ambient Danger Zone Limit
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Per international food safety science (FSSAI / FDA), cooked perishable food left at ambient temperature (between 5°C and 60°C) for more than <strong>4 hours</strong> enters the rapid bacterial proliferation zone.
          </p>
          <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800 text-[11px] text-rose-200 flex items-start gap-2">
            <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span>FoodBridge platform automatically detects preparation timestamps and halts donations over 4 hours old at room temperature.</span>
          </div>
        </div>

        {/* Pillar 2: Thermal Storage */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <Thermometer className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">
            2. Active Thermal Maintenance
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Surplus banquet food is only safe if either:
          </p>
          <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside">
            <li><strong>Hot Chain:</strong> Kept in bain-marie/chafing units at or above <strong>60°C (140°F)</strong>.</li>
            <li><strong>Cold Chain:</strong> Rapidly chilled and stored below <strong>5°C (41°F)</strong> within 2 hours.</li>
          </ul>
          <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800 text-[11px] text-emerald-300 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>Volunteers verify container warmth or cold packaging upon pickup at the donor kitchen.</span>
          </div>
        </div>

        {/* Pillar 3: Packaging & Sealed Transport */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-400 flex items-center justify-center">
            <Package className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">
            3. Tamper-Evident & Food-Grade Packaging
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Uncovered dishes or items in non-food grade polythene bags are rejected. Accepted packaging methods:
          </p>
          <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside">
            <li>Stainless steel catering pots with secure lid clamps.</li>
            <li>Food-grade heavy aluminum foil boxes with sealed lids.</li>
            <li>Insulated transport courier containers for two-wheeler transit.</li>
          </ul>
        </div>

        {/* Pillar 4: Recipient Acceptance & Verification */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">
            4. Recipient Inspection & Reheating
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            The recipient care home kitchen retains absolute veto power. If an item fails the aroma, color, or container seal test, the shelter rejects the item.
          </p>
          <div className="p-3 rounded-xl bg-slate-800 border border-slate-700 text-[11px] text-slate-300 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>Care home cooks are instructed to boil/reheat hot meals to 74°C (165°F) for 2 minutes prior to serving residents.</span>
          </div>
        </div>
      </div>

      {/* Interactive Tool: Gemini AI Food Handling Reminders Generator */}
      <section className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-emerald-500/40 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-700 pb-3">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-400">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>Gemini AI Food-Handling Reminders Assistant</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-0.5">
              Generate Tailored Transit Precautions for Any Food Item
            </h2>
          </div>
          <span className="text-[10px] font-mono text-emerald-300 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800 self-start sm:self-auto">
            Real-time AI Guidance
          </span>
        </div>

        <form onSubmit={handleGenerateReminders} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Food Item / Dish Name
            </label>
            <input
              type="text"
              value={foodItem}
              onChange={(e) => setFoodItem(e.target.value)}
              placeholder="e.g. Sambar, Idlis, Coconut Chutney"
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Food Category
            </label>
            <select
              value={foodType}
              onChange={(e) => setFoodType(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="wedding_banquet">Wedding Banquet Feasts</option>
              <option value="hotel_buffet">Hotel Buffet Dishes</option>
              <option value="bakery">Bakery / Bread Items</option>
              <option value="cooked_rice_curry">Cooked Rice, Dal & Gravy</option>
              <option value="dairy_sweets">Milk Sweets / Desserts (High Risk)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Volunteer Transit Mode
            </label>
            <select
              value={transitMode}
              onChange={(e) => setTransitMode(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="Two-Wheeler with insulated delivery bag">Motorbike with Delivery Bag</option>
              <option value="Car with rear boot flat placement">Car / SUV</option>
              <option value="Auto-rickshaw covered floor">Auto-Rickshaw</option>
              <option value="Bicycle front basket">Bicycle Carrier</option>
            </select>
          </div>

          <div className="sm:col-span-3">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Generating AI Food-Handling Reminders...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Generate AI Handling Reminders</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* AI Results Output */}
        {aiReminders && (
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-emerald-500/40 space-y-4 animate-in fade-in">
            <div className="text-xs font-bold uppercase text-emerald-400">
              AI Food Handling Directives for "{foodItem}"
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
                <span className="text-slate-400 block mb-0.5">Critical Temperature Guideline:</span>
                <span className="font-semibold text-amber-300">{aiReminders.temperatureGuidelines}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
                <span className="text-slate-400 block mb-0.5">Delivery Target Window:</span>
                <span className="font-semibold text-emerald-300">{aiReminders.deliveryWindowTip}</span>
              </div>
            </div>

            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-300">Volunteer Transit Checklist:</span>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                {aiReminders.reminders.map((rem, idx) => (
                  <li
                    key={idx}
                    className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-800 flex items-start gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{rem}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </section>
    </div>
  );
};
