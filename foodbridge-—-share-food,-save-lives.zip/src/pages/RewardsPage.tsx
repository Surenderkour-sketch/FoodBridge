import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Award,
  ShieldCheck,
  Zap,
  HeartHandshake,
  Crown,
  Moon,
  Sparkles,
  AlertTriangle,
  Heart,
  Stethoscope,
  Briefcase,
  CheckCircle2,
  Lock,
  ArrowRight,
  Send,
} from 'lucide-react';

export const RewardsPage: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const { currentUser, users, badges, showToast } = useApp();

  const [sponsorInquiryModal, setSponsorInquiryModal] = useState(false);
  const [sponsorName, setSponsorName] = useState('');
  const [sponsorEmail, setSponsorEmail] = useState('');
  const [sponsorOrg, setSponsorOrg] = useState('');
  const [sponsorNotes, setSponsorNotes] = useState('');

  const userBadges = currentUser.badges || [];
  const completedDeliveries = currentUser.completedDeliveriesCount || 0;
  const volunteerPoints = currentUser.volunteerPoints || 0;

  // Filter volunteers for leaderboard
  const volunteerLeaderboard = [...users]
    .filter((u) => u.roles.includes('volunteer'))
    .sort((a, b) => (b.volunteerPoints || 0) - (a.volunteerPoints || 0));

  const getBadgeIcon = (iconName: string, isUnlocked: boolean) => {
    const iconClass = `w-7 h-7 ${isUnlocked ? 'text-amber-400' : 'text-slate-600'}`;
    switch (iconName) {
      case 'Award':
        return <Award className={iconClass} />;
      case 'ShieldCheck':
        return <ShieldCheck className={iconClass} />;
      case 'Zap':
        return <Zap className={iconClass} />;
      case 'HeartHandshake':
        return <HeartHandshake className={iconClass} />;
      case 'Moon':
        return <Moon className={iconClass} />;
      case 'Crown':
        return <Crown className={iconClass} />;
      default:
        return <Sparkles className={iconClass} />;
    }
  };

  const handleSponsorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sponsorName || !sponsorEmail) {
      showToast('Please provide your name and work email.', 'warning');
      return;
    }
    showToast(
      'Thank you! Your corporate sponsorship inquiry has been registered. Our partnership team will reach out with the proposed medical CSR charter.',
      'success',
      'Inquiry Submitted'
    );
    setSponsorInquiryModal(false);
    setSponsorName('');
    setSponsorEmail('');
    setSponsorOrg('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <Award className="w-3.5 h-3.5" />
            <span>Volunteer Honors & Recognition</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Rewards & Volunteer Badges
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">
            Points and badges are awarded exclusively upon verified recipient delivery handover.
          </p>
        </div>

        {/* Current Volunteer Summary Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/30 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 font-extrabold text-xl">
            {currentUser.name.slice(0, 1)}
          </div>
          <div>
            <div className="text-xs text-slate-400">Current Volunteer</div>
            <div className="font-bold text-white text-sm">{currentUser.name}</div>
            <div className="text-xs text-amber-400 font-semibold mt-0.5">
              {volunteerPoints} Points • {userBadges.length} Badges Won
            </div>
          </div>
        </div>
      </div>

      {/* Badges Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Delivery Badges Showcase</span>
          </h2>
          <span className="text-xs text-slate-400">
            {userBadges.length} of {badges.length} unlocked
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {badges.map((badge) => {
            const isUnlocked = userBadges.includes(badge.id);

            return (
              <div
                key={badge.id}
                className={`p-5 rounded-3xl border transition relative overflow-hidden flex flex-col justify-between ${
                  isUnlocked
                    ? 'bg-slate-900/90 border-amber-500/40 shadow-lg'
                    : 'bg-slate-900/40 border-slate-800 opacity-60'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div
                      className={`w-12 h-12 rounded-2xl flex items-center justify-center border ${
                        isUnlocked
                          ? 'bg-amber-500/20 border-amber-500/40'
                          : 'bg-slate-800 border-slate-700'
                      }`}
                    >
                      {getBadgeIcon(badge.iconName, isUnlocked)}
                    </div>

                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        isUnlocked
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-500 border border-slate-700'
                      }`}
                    >
                      {isUnlocked ? 'Unlocked' : 'Locked'}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white">{badge.name}</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {badge.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500 font-mono uppercase">
                    Tier: {badge.tier}
                  </span>
                  {isUnlocked ? (
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Verified Active</span>
                    </span>
                  ) : (
                    <span className="text-slate-500 flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5" />
                      <span>Complete mission to earn</span>
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* PROPOSED SPONSOR-FUNDED MEDICAL BENEFIT PROGRAM (STRICT NOTICE) */}
      <section className="relative p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-amber-950/20 border-2 border-amber-500/50 shadow-2xl space-y-6">
        {/* Important Warning / Transparency Banner */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs">
          <div className="flex items-center gap-2 font-semibold">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            <span>
              <strong>Concept Status:</strong> Proposed Sponsor-Funded Medical Benefit Program (Currently Inactive / Pending Sponsorship).
            </span>
          </div>
          <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-700 shrink-0">
            NOT CURRENTLY ACTIVE
          </span>
        </div>

        <div className="max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400">
            <Stethoscope className="w-4 h-4 text-amber-400" />
            <span>Future Wellness Vision for Active Volunteer Families</span>
          </div>
          <h2 className="text-2xl font-black text-white">
            Proposed Community Volunteer Health Shield
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Our volunteers brave traffic, heat, and late nights to feed hungry children and elderly people.
            FoodBridge is designing a <strong>sponsor-funded medical benefit program</strong> to cover volunteers and their immediate families.
            <br />
            <em className="text-amber-300">
              *Transparency Guarantee: This program is strictly a proposal seeking CSR foundation or healthcare corporate partners. It is NOT active today and will only be activated when a real sponsor partnership is funded.
            </em>
          </p>
        </div>

        {/* Proposed Benefit Tiers */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* Tier 1 */}
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-400">
              <span className="text-amber-400">PROPOSED TIER 1</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                10+ Runs
              </span>
            </div>
            <h4 className="font-bold text-white text-sm">Annual Health Checkup</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Proposed full diagnostic blood panel and vitals checkup voucher at partner clinics for active volunteers.
            </p>
            <div className="text-[10px] text-amber-400/80 font-mono pt-1">
              Status: Seeking Lab Partner
            </div>
          </div>

          {/* Tier 2 */}
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-400">
              <span className="text-amber-400">PROPOSED TIER 2</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                25+ Runs
              </span>
            </div>
            <h4 className="font-bold text-white text-sm">Delivery Transit Accidental Cover</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Proposed micro-insurance policy covering emergency accidental medical expenses incurred during active food rescue transit.
            </p>
            <div className="text-[10px] text-amber-400/80 font-mono pt-1">
              Status: Seeking InsurTech Sponsor
            </div>
          </div>

          {/* Tier 3 */}
          <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-400">
              <span className="text-amber-400">PROPOSED TIER 3</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                50+ Runs
              </span>
            </div>
            <h4 className="font-bold text-white text-sm">Family Wellness Care Fund</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Proposed emergency medicine subsidy & pediatric care consultations for the volunteer's spouse and dependent children.
            </p>
            <div className="text-[10px] text-amber-400/80 font-mono pt-1">
              Status: Seeking Corporate CSR
            </div>
          </div>
        </div>

        {/* Sponsor Call to Action */}
        <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-400">
            Are you a hospital chain, health insurance firm, or CSR grant manager? Help us turn this proposal into reality.
          </div>
          <button
            onClick={() => setSponsorInquiryModal(true)}
            className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition shadow-md shadow-amber-500/20 shrink-0 flex items-center gap-1.5"
          >
            <Briefcase className="w-3.5 h-3.5" />
            <span>Partner as Health Benefit Sponsor →</span>
          </button>
        </div>
      </section>

      {/* Volunteer Leaderboard */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Crown className="w-4 h-4 text-amber-400" />
            <span>Community Volunteer Leaderboard</span>
          </h2>
          <span className="text-xs text-slate-400">Updated in real-time</span>
        </div>

        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          {volunteerLeaderboard.map((vol, index) => {
            const isCurrent = currentUser.id === vol.id;

            return (
              <div
                key={vol.id}
                className={`p-3.5 rounded-2xl flex items-center justify-between gap-3 transition ${
                  isCurrent
                    ? 'bg-amber-950/40 border border-amber-500/40 text-amber-200'
                    : 'bg-slate-800/40 border border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-7 h-7 rounded-lg font-bold text-xs flex items-center justify-center ${
                      index === 0
                        ? 'bg-amber-400 text-slate-950'
                        : index === 1
                        ? 'bg-slate-300 text-slate-950'
                        : index === 2
                        ? 'bg-amber-700 text-white'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    #{index + 1}
                  </div>
                  <div>
                    <div className="font-bold text-sm text-white flex items-center gap-2">
                      <span>{vol.name}</span>
                      {isCurrent && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-semibold">
                          You
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {vol.completedDeliveriesCount || 0} verified deliveries • {vol.city}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-extrabold text-amber-400">
                    {vol.volunteerPoints || 0} pts
                  </div>
                  <div className="text-[10px] text-slate-500">
                    {(vol.badges || []).length} Badges
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Sponsor Inquiry Modal */}
      {sponsorInquiryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <form
            onSubmit={handleSponsorSubmit}
            className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700 p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-lg text-white">Sponsor Volunteer Medical Shield</h3>
                <p className="text-xs text-slate-400">
                  CSR & Healthcare Partner Inquiry (Help activate this program)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSponsorInquiryModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Your Name / Representative
              </label>
              <input
                type="text"
                value={sponsorName}
                onChange={(e) => setSponsorName(e.target.value)}
                placeholder="Dr. Sunil Rao"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-400"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Organization / Corporate CSR Foundation
              </label>
              <input
                type="text"
                value={sponsorOrg}
                onChange={(e) => setSponsorOrg(e.target.value)}
                placeholder="e.g. HealthFirst Foundation / Hospital Chain"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Work Email Address
              </label>
              <input
                type="email"
                value={sponsorEmail}
                onChange={(e) => setSponsorEmail(e.target.value)}
                placeholder="sunil.rao@healthfirst.org"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-400"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Proposed Partnership Scope
              </label>
              <textarea
                rows={3}
                value={sponsorNotes}
                onChange={(e) => setSponsorNotes(e.target.value)}
                placeholder="We would like to sponsor annual health checkups or emergency insurance for 100 active volunteers..."
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSponsorInquiryModal(false)}
                className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition"
              >
                Submit CSR Proposal
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
