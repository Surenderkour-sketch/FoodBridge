import React from 'react';
import { useApp } from '../context/AppContext';
import {
  UtensilsCrossed,
  Heart,
  ArrowRight,
  ShieldCheck,
  Bike,
  Sparkles,
  Users,
  Award,
  Building2,
  Clock,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

export const HomePage: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const { impactStats, donations, switchPersona, setActiveRole } = useApp();

  const availableCount = donations.filter((d) => d.status === 'available').length;
  const inTransitCount = donations.filter((d) => d.status === 'accepted' || d.status === 'picked_up').length;

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-8 pb-12 sm:pt-16 sm:pb-20 border-b border-slate-800 bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          {/* Mission Tag */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-6 animate-pulse">
            <Heart className="w-3.5 h-3.5 fill-emerald-400" />
            <span>Mission: Zero Food Waste • Zero Hunger</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight leading-tight sm:leading-none max-w-4xl mx-auto">
            FoodBridge
            <span className="block text-2xl sm:text-4xl font-extrabold bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300 bg-clip-text text-transparent mt-2">
              Share Food, Save Lives
            </span>
          </h1>

          <p className="mt-5 text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Connecting surplus food from <strong>marriage halls, hotels, caterers, and homes</strong> with{' '}
            <strong>orphanages, old-age homes, and shelters</strong> through verified, community volunteer delivery runs.
          </p>

          {/* Quick Action Buttons */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3 sm:gap-4">
            <button
              onClick={() => {
                setActiveRole('donor');
                onNavigate('donate');
              }}
              className="px-6 py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:from-emerald-400 hover:to-teal-400 transition shadow-lg shadow-emerald-500/25 flex items-center gap-2 group"
            >
              <span>Donate Surplus Food</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
            </button>

            <button
              onClick={() => {
                setActiveRole('recipient');
                onNavigate('available');
              }}
              className="px-6 py-3.5 rounded-xl font-bold text-sm bg-slate-800 text-white hover:bg-slate-700 border border-slate-700 transition flex items-center gap-2"
            >
              <span>Request Food for Care Home</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">
                {availableCount} Available
              </span>
            </button>

            <button
              onClick={() => {
                setActiveRole('volunteer');
                onNavigate('volunteer');
              }}
              className="px-6 py-3.5 rounded-xl font-bold text-sm bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 border border-amber-500/40 transition flex items-center gap-2"
            >
              <Bike className="w-4 h-4 text-amber-400" />
              <span>Deliver as Volunteer</span>
            </button>
          </div>

          {/* Live System Indicator */}
          <div className="mt-6 flex items-center justify-center gap-4 text-xs text-slate-400">
            <div className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
              <span>{availableCount} Active Food Listings</span>
            </div>
            <span>•</span>
            <div className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-amber-400" />
              <span>{inTransitCount} Deliveries In Progress</span>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Quick-Test Launcher for Judges */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-800/60 border border-emerald-500/30 backdrop-blur-md relative overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400 mb-1">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Instant Demo Launcher (Judge Testing)</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white">
                Test the Complete End-to-End Workflow in 30 Seconds
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                Click any role to immediately assume that identity and test live features without signup friction.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Step 1 Donor */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700 hover:border-emerald-500/60 transition group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-2">
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                    Step 1: Donor
                  </span>
                  <span>Wedding Hall</span>
                </div>
                <h3 className="font-bold text-white text-base group-hover:text-emerald-300 transition">
                  Grand Royale Banquets
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Post 90 servings of fresh wedding feast with automated Gemini AI food safety verification.
                </p>
              </div>
              <button
                onClick={() => {
                  switchPersona('user_donor_1');
                  setActiveRole('donor');
                  onNavigate('donate');
                }}
                className="mt-4 w-full py-2 px-3 rounded-xl bg-emerald-600/20 hover:bg-emerald-600 border border-emerald-500/30 text-emerald-200 hover:text-white font-semibold text-xs transition flex items-center justify-center gap-1.5"
              >
                <span>Launch as Donor</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Step 2 Recipient */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700 hover:border-teal-500/60 transition group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-2">
                  <span className="px-2 py-0.5 rounded bg-teal-950 text-teal-300 border border-teal-800">
                    Step 2: Recipient
                  </span>
                  <span>45 Children</span>
                </div>
                <h3 className="font-bold text-white text-base group-hover:text-teal-300 transition">
                  Sneha Children Orphanage
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Use Gemini AI to match surplus banquet food with resident dietary needs and click "Request Food".
                </p>
              </div>
              <button
                onClick={() => {
                  switchPersona('user_recipient_1');
                  setActiveRole('recipient');
                  onNavigate('available');
                }}
                className="mt-4 w-full py-2 px-3 rounded-xl bg-teal-600/20 hover:bg-teal-600 border border-teal-500/30 text-teal-200 hover:text-white font-semibold text-xs transition flex items-center justify-center gap-1.5"
              >
                <span>Launch as Recipient</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Step 3 Volunteer */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700 hover:border-amber-500/60 transition group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-2">
                  <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
                    Step 3: Volunteer
                  </span>
                  <span>Courier Hero</span>
                </div>
                <h3 className="font-bold text-white text-base group-hover:text-amber-300 transition">
                  Rahul Sharma (Courier)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Accept pending delivery, verify food pickup PIN, confirm delivery handover, and unlock instant badges!
                </p>
              </div>
              <button
                onClick={() => {
                  switchPersona('user_volunteer_1');
                  setActiveRole('volunteer');
                  onNavigate('volunteer');
                }}
                className="mt-4 w-full py-2 px-3 rounded-xl bg-amber-600/20 hover:bg-amber-600 border border-amber-500/30 text-amber-200 hover:text-white font-semibold text-xs transition flex items-center justify-center gap-1.5"
              >
                <span>Launch as Volunteer</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Diagram */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-xs font-bold uppercase tracking-widest text-emerald-400">
            End-To-End Lifecycle
          </h2>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            How FoodBridge Saves Every Meal
          </h3>
          <p className="text-sm text-slate-400 mt-2">
            Every step is protected by food safety windows, verified handover codes, and volunteer rewards.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Step 1 */}
          <div className="relative p-6 rounded-2xl bg-slate-800/40 border border-slate-800 hover:border-slate-700 transition">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-lg mb-4">
              1
            </div>
            <h4 className="font-bold text-white text-base">Donor Posts Surplus</h4>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Marriage hall or restaurant inputs meal quantity, preparation time, and storage method. Automated safety check verifies shelf-life.
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center gap-2 text-[11px] text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Danger-zone food rejected</span>
            </div>
          </div>

          {/* Step 2 */}
          <div className="relative p-6 rounded-2xl bg-slate-800/40 border border-slate-800 hover:border-slate-700 transition">
            <div className="w-12 h-12 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold text-lg mb-4">
              2
            </div>
            <h4 className="font-bold text-white text-base">Care Home Requests</h4>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Orphanages and shelters view available food or receive Gemini AI match recommendations based on headcount and dietary fit.
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center gap-2 text-[11px] text-teal-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Smart AI Matching</span>
            </div>
          </div>

          {/* Step 3 */}
          <div className="relative p-6 rounded-2xl bg-slate-800/40 border border-slate-800 hover:border-slate-700 transition">
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-lg mb-4">
              3
            </div>
            <h4 className="font-bold text-white text-base">Volunteer Collects</h4>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Any willing registered citizen accepts the mission on their phone, arrives at donor kitchen, and confirms container pickup.
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center gap-2 text-[11px] text-amber-400">
              <Bike className="w-3.5 h-3.5" />
              <span>Zero-barrier volunteer sign-up</span>
            </div>
          </div>

          {/* Step 4 */}
          <div className="relative p-6 rounded-2xl bg-slate-800/40 border border-slate-800 hover:border-slate-700 transition">
            <div className="w-12 h-12 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-lg mb-4">
              4
            </div>
            <h4 className="font-bold text-white text-base">Verified Handover</h4>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Shelter supervisor checks food quality and verifies delivery with secure PIN. System instantly awards volunteer points & badges!
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center gap-2 text-[11px] text-rose-400">
              <Award className="w-3.5 h-3.5" />
              <span>Instant Badges Awarded</span>
            </div>
          </div>
        </div>
      </section>

      {/* Real-time Impact Statistics */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8">
            <div>
              <div className="text-xs uppercase font-bold text-emerald-400 tracking-wider">
                Live Community Milestones
              </div>
              <h3 className="text-2xl font-bold text-white mt-1">Our Collective Impact</h3>
            </div>
            <button
              onClick={() => onNavigate('impact')}
              className="px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold transition flex items-center gap-2"
            >
              <span>View Full Analytics & AI Report</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center">
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <div className="text-3xl sm:text-4xl font-black text-emerald-400">
                {impactStats.mealsDelivered.toLocaleString()}
              </div>
              <div className="text-xs text-slate-300 font-medium mt-1">Meals Delivered</div>
              <div className="text-[10px] text-slate-500 mt-0.5">To children & senior homes</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <div className="text-3xl sm:text-4xl font-black text-amber-400">
                {impactStats.kgRescued.toLocaleString()} kg
              </div>
              <div className="text-xs text-slate-300 font-medium mt-1">Food Rescued</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Prevented from landfills</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <div className="text-3xl sm:text-4xl font-black text-teal-400">
                {impactStats.completedDeliveries}
              </div>
              <div className="text-xs text-slate-300 font-medium mt-1">Completed Runs</div>
              <div className="text-[10px] text-slate-500 mt-0.5">100% verified deliveries</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
              <div className="text-3xl sm:text-4xl font-black text-rose-400">
                {impactStats.activeVolunteers}
              </div>
              <div className="text-xs text-slate-300 font-medium mt-1">Active Volunteers</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Everyday local heroes</div>
            </div>
          </div>
        </div>
      </section>

      {/* Dual Role Feature Highlight */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400">
              <Users className="w-4 h-4" />
              <span>Multi-Role Flexibility</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white leading-snug">
              Be a Food Donor Today, and a Delivery Hero Tomorrow
            </h3>
            <p className="text-slate-300 text-sm leading-relaxed">
              FoodBridge recognizes that community members are versatile. A restaurant owner or home chef can donate leftover feast food in the morning, and grab their scooter to deliver meals to an orphanage in the evening.
            </p>
            <div className="flex flex-col gap-2.5 pt-2">
              <div className="flex items-center gap-2.5 text-xs text-slate-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Single account with instant 1-click role toggling</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs text-slate-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Anyone can volunteer without complex vehicle registrations</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs text-slate-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Earn points and badges only upon recipient verification</span>
              </div>
            </div>
            <div className="pt-2">
              <button
                onClick={() => onNavigate('auth')}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition border border-slate-700"
              >
                Register or Manage Roles
              </button>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-bold uppercase text-slate-400">Sample Dual-Role Profile</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">Active</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-500 to-emerald-500 flex items-center justify-center text-white font-bold text-lg">
                RS
              </div>
              <div>
                <h4 className="font-bold text-white text-base">Rahul Sharma</h4>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="text-emerald-400 font-medium">Donor (Home Feasts)</span>
                  <span>•</span>
                  <span className="text-amber-400 font-medium">Volunteer (Two-Wheeler)</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center pt-2">
              <div className="p-2.5 rounded-xl bg-slate-800/80">
                <div className="text-lg font-bold text-amber-400">650</div>
                <div className="text-[10px] text-slate-400">Points</div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-800/80">
                <div className="text-lg font-bold text-emerald-400">6</div>
                <div className="text-[10px] text-slate-400">Deliveries</div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-800/80">
                <div className="text-lg font-bold text-teal-400">4</div>
                <div className="text-[10px] text-slate-400">Badges Won</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
