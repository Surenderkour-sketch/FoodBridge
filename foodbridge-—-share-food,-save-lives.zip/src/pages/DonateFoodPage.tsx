import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { FoodCategory, FoodDietType, StorageCondition, PackagingType } from '../types';
import { checkFoodSafetyWithAi, FoodSafetyReport } from '../services/geminiService';
import {
  PackagePlus,
  ShieldCheck,
  AlertTriangle,
  Clock,
  Sparkles,
  MapPin,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Loader2,
  Flame,
  Snowflake,
  Sun,
  Layers,
} from 'lucide-react';

export const DonateFoodPage: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const { currentUser, addDonation, showToast } = useApp();

  const [foodName, setFoodName] = useState('');
  const [category, setCategory] = useState<FoodCategory>('wedding_banquet');
  const [dietType, setDietType] = useState<FoodDietType>('veg');
  const [quantityServings, setQuantityServings] = useState('60');
  const [estimatedWeightKg, setEstimatedWeightKg] = useState('25');
  const [numberOfContainers, setNumberOfContainers] = useState('3');
  const [description, setDescription] = useState('');

  // Safety & Storage parameters
  const [prepTimeHoursAgo, setPrepTimeHoursAgo] = useState<number>(1.5);
  const [availableUntilHours, setAvailableUntilHours] = useState<number>(4);
  const [storageCondition, setStorageCondition] = useState<StorageCondition>('hot_maintained');
  const [packaging, setPackaging] = useState<PackagingType>('sealed_steel_containers');
  const [allergenInfo, setAllergenInfo] = useState('');

  // Logistics
  const [pickupAddress, setPickupAddress] = useState(currentUser.address || 'Grand Wedding Palace, Outer Ring Road');
  const [pickupLandmark, setPickupLandmark] = useState('Near Marathahalli Overbridge');
  const [pickupCity, setPickupCity] = useState(currentUser.city || 'Bengaluru');
  const [pickupPinCode, setPickupPinCode] = useState('560037');
  const [donorPhone, setDonorPhone] = useState(currentUser.phone || '+91 98450 12345');

  // AI Safety evaluation state
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [safetyReport, setSafetyReport] = useState<FoodSafetyReport | null>(null);

  // Quick Preset Sample Fillers for Judges
  const fillSample = (type: 'wedding_fresh' | 'hotel_fresh' | 'unsafe_expired') => {
    if (type === 'wedding_fresh') {
      setFoodName('Royal Wedding Feast: Shahi Pulao, Paneer Gravy & 100 Tawa Rotis');
      setCategory('wedding_banquet');
      setDietType('veg');
      setQuantityServings('95');
      setEstimatedWeightKg('40');
      setNumberOfContainers('4');
      setPrepTimeHoursAgo(1.5);
      setAvailableUntilHours(5);
      setStorageCondition('hot_maintained');
      setPackaging('sealed_steel_containers');
      setDescription('Pristine unserved wedding dinner surplus. Hot buffet kept in chafing containers until 2:30 PM.');
      setSafetyReport(null);
      showToast('Loaded fresh wedding banquet sample.', 'info');
    } else if (type === 'hotel_fresh') {
      setFoodName('Hotel Buffet: Dal Makhani, Jeera Rice & Subz Korma');
      setCategory('hotel_buffet');
      setDietType('veg');
      setQuantityServings('40');
      setEstimatedWeightKg('18');
      setNumberOfContainers('2');
      setPrepTimeHoursAgo(2);
      setAvailableUntilHours(4);
      setStorageCondition('refrigerated');
      setPackaging('foil_packed_boxes');
      setDescription('Buffet reserve dishes packed straight from hotel warming units.');
      setSafetyReport(null);
      showToast('Loaded hotel buffet sample.', 'info');
    } else if (type === 'unsafe_expired') {
      setFoodName('Cooked Mixed Vegetable Stew & Rice (Room Temp 5 hrs)');
      setCategory('event_surplus');
      setDietType('veg');
      setQuantityServings('30');
      setEstimatedWeightKg('12');
      setNumberOfContainers('2');
      setPrepTimeHoursAgo(5.5); // Greater than 4 hours! Danger zone!
      setAvailableUntilHours(1);
      setStorageCondition('room_temp_ambient');
      setPackaging('requires_volunteer_boxes');
      setDescription('Left on open buffet table since morning without heating.');
      setSafetyReport(null);
      showToast('Loaded danger-zone food sample (Will trigger AI safety rejection test).', 'warning');
    }
  };

  const handleRunSafetyCheck = async () => {
    if (!foodName.trim()) {
      showToast('Please provide a food item name first.', 'warning');
      return;
    }
    setIsEvaluating(true);
    try {
      const report = await checkFoodSafetyWithAi({
        foodName,
        foodType: category,
        prepTimeHoursAgo,
        storageCondition,
        tempEstimate: storageCondition === 'hot_maintained' ? '> 65°C hot' : storageCondition === 'refrigerated' ? '< 5°C chilled' : 'Ambient room temp ~28°C',
        packaging,
        isPerishable: true,
      });
      setSafetyReport(report);
      if (report.safeToDeliver) {
        showToast('Food safety evaluated: APPROVED for donation dispatch!', 'success');
      } else {
        showToast('Food safety evaluated: REJECTED as unsafe (exceeds ambient window).', 'error');
      }
    } catch {
      showToast('Safety check completed via offline safety engine.', 'info');
    } finally {
      setIsEvaluating(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!foodName.trim()) {
      showToast('Please specify the food name.', 'error');
      return;
    }

    // Safety Rule Enforcement:
    // If prepared over 4 hours ago and kept at room temperature, strictly block!
    const isDangerZone = prepTimeHoursAgo >= 4 && storageCondition === 'room_temp_ambient';

    if (isDangerZone) {
      showToast(
        'Cannot post: Food has been at room temperature for over 4 hours (Bacterial Danger Zone). FoodBridge does not permit serving unsafe food to orphanages or shelters.',
        'error',
        'Safety Rejection'
      );
      return;
    }

    if (safetyReport && !safetyReport.safeToDeliver) {
      showToast('Cannot post: AI Safety audit flagged this batch as unsafe for consumption.', 'error');
      return;
    }

    const newDon = addDonation({
      foodName,
      category,
      dietType,
      quantityServings: Number(quantityServings) || 50,
      estimatedWeightKg: Number(estimatedWeightKg) || 20,
      numberOfContainers: Number(numberOfContainers) || 2,
      description,
      prepTime: `Prepared ${prepTimeHoursAgo} hrs ago`,
      prepTimeHoursAgo,
      availableUntil: `Consume within ${availableUntilHours} hours`,
      storageCondition,
      packaging,
      pickupAddress,
      pickupLandmark,
      pickupCity,
      pickupPinCode,
      donorPhone,
      allergenInfo: allergenInfo || 'None reported',
      isSafetyApproved: true,
      safetyScore: safetyReport ? safetyReport.safetyScore : 92,
      safetyNotes: safetyReport ? safetyReport.verdictTitle : 'Standard safety checks satisfied.',
    });

    onNavigate('available');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <PackagePlus className="w-3.5 h-3.5" />
            <span>Surplus Food Donor Portal</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Donate Surplus Food
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">
            Turn banquet and wedding surplus into fresh dinners for orphanages and shelters.
          </p>
        </div>

        {/* Quick Sample Presets */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-semibold text-slate-400 uppercase">Presets:</span>
          <button
            type="button"
            onClick={() => fillSample('wedding_fresh')}
            className="px-2.5 py-1.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-300 text-xs font-medium transition"
          >
            Wedding Feast
          </button>
          <button
            type="button"
            onClick={() => fillSample('hotel_fresh')}
            className="px-2.5 py-1.5 rounded-lg bg-teal-950/60 hover:bg-teal-900 border border-teal-700/60 text-teal-300 text-xs font-medium transition"
          >
            Hotel Buffet
          </button>
          <button
            type="button"
            onClick={() => fillSample('unsafe_expired')}
            className="px-2.5 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900 border border-rose-700/60 text-rose-300 text-xs font-medium transition"
            title="Test food safety rejection"
          >
            ⚠️ Test Danger Food
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Section 1: Food Details */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-5">
          <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-400 border-b border-slate-800 pb-3 flex items-center gap-2">
            <Layers className="w-4 h-4" />
            <span>1. Food Description & Quantity</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Food Name / Banquet Menu Items <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={foodName}
                onChange={(e) => setFoodName(e.target.value)}
                placeholder="e.g. Wedding Feast: Veg Pulao, Paneer Gravy, Dal & 100 Rotis"
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Source Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as FoodCategory)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              >
                <option value="wedding_banquet">Wedding Hall Banquet</option>
                <option value="hotel_buffet">Hotel / Commercial Buffet</option>
                <option value="restaurant_meals">Restaurant Kitchen Surplus</option>
                <option value="event_surplus">Corporate / Festival Event</option>
                <option value="home_cooked">Home Cooked Excess</option>
                <option value="bakery">Bakery / Fresh Bread</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Dietary Type <span className="text-rose-400">*</span>
              </label>
              <select
                value={dietType}
                onChange={(e) => setDietType(e.target.value as FoodDietType)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              >
                <option value="veg">Vegetarian (Pure Veg)</option>
                <option value="non_veg">Non-Vegetarian</option>
                <option value="vegan">Vegan (Plant Based)</option>
                <option value="jain">Jain (No Root Veg / Onion / Garlic)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Number of Servings (Meals) <span className="text-rose-400">*</span>
              </label>
              <input
                type="number"
                min="5"
                max="2000"
                value={quantityServings}
                onChange={(e) => setQuantityServings(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                required
              />
              <span className="text-[10px] text-slate-500 mt-1 block">e.g. 50 meals will feed 50 children</span>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Estimated Total Weight (kg)
              </label>
              <input
                type="number"
                min="1"
                max="500"
                value={estimatedWeightKg}
                onChange={(e) => setEstimatedWeightKg(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Number of Pots / Containers
              </label>
              <input
                type="number"
                min="1"
                max="50"
                value={numberOfContainers}
                onChange={(e) => setNumberOfContainers(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Allergen / Special Ingredients Note
              </label>
              <input
                type="text"
                value={allergenInfo}
                onChange={(e) => setAllergenInfo(e.target.value)}
                placeholder="e.g. Contains dairy (paneer) and cashew paste"
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Additional Notes / Handling Advice
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="e.g. Rice and gravy are packed separately. Kept warm in chafing trays."
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Food Safety & Preparation Verification */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4" />
                <span>2. Food Safety & Temperature Verification</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Critical check: Food kept at ambient temperature over 4 hours will be flagged unsafe and rejected.
              </p>
            </div>

            <button
              type="button"
              onClick={handleRunSafetyCheck}
              disabled={isEvaluating}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-semibold transition flex items-center gap-1.5 self-start sm:self-auto"
            >
              {isEvaluating ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Inspecting with Gemini AI...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Verify Safety with Gemini AI</span>
                </>
              )}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Preparation Time (Hours Ago) <span className="text-rose-400">*</span>
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="0.5"
                  max="8"
                  step="0.5"
                  value={prepTimeHoursAgo}
                  onChange={(e) => setPrepTimeHoursAgo(Number(e.target.value))}
                  className="flex-1 accent-emerald-500"
                />
                <span className="text-xs font-mono font-bold text-white px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 min-w-16 text-center">
                  {prepTimeHoursAgo} hrs ago
                </span>
              </div>
              {prepTimeHoursAgo >= 4 && storageCondition === 'room_temp_ambient' && (
                <p className="text-[11px] text-rose-400 mt-1 flex items-center gap-1 font-semibold">
                  <AlertTriangle className="w-3 h-3" />
                  <span>Exceeds safe room-temperature threshold (&gt;4h)!</span>
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Available Until (Safe Window Remaining)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="1"
                  max="8"
                  step="1"
                  value={availableUntilHours}
                  onChange={(e) => setAvailableUntilHours(Number(e.target.value))}
                  className="flex-1 accent-emerald-500"
                />
                <span className="text-xs font-mono font-bold text-white px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 min-w-16 text-center">
                  Next {availableUntilHours} hrs
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Storage Method Since Cooking <span className="text-rose-400">*</span>
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setStorageCondition('hot_maintained')}
                  className={`p-2.5 rounded-xl border text-left text-xs transition ${
                    storageCondition === 'hot_maintained'
                      ? 'bg-amber-950/60 border-amber-500 text-amber-200'
                      : 'bg-slate-800/40 border-slate-700 text-slate-400'
                  }`}
                >
                  <Flame className="w-4 h-4 mb-1 text-amber-400" />
                  <div className="font-semibold text-[11px]">Hot Kept</div>
                  <div className="text-[9px] text-slate-400">&gt;60°C chafing</div>
                </button>

                <button
                  type="button"
                  onClick={() => setStorageCondition('refrigerated')}
                  className={`p-2.5 rounded-xl border text-left text-xs transition ${
                    storageCondition === 'refrigerated'
                      ? 'bg-cyan-950/60 border-cyan-500 text-cyan-200'
                      : 'bg-slate-800/40 border-slate-700 text-slate-400'
                  }`}
                >
                  <Snowflake className="w-4 h-4 mb-1 text-cyan-400" />
                  <div className="font-semibold text-[11px]">Chilled</div>
                  <div className="text-[9px] text-slate-400">&lt;5°C fridge</div>
                </button>

                <button
                  type="button"
                  onClick={() => setStorageCondition('room_temp_ambient')}
                  className={`p-2.5 rounded-xl border text-left text-xs transition ${
                    storageCondition === 'room_temp_ambient'
                      ? 'bg-slate-800 border-rose-500 text-rose-200'
                      : 'bg-slate-800/40 border-slate-700 text-slate-400'
                  }`}
                >
                  <Sun className="w-4 h-4 mb-1 text-rose-400" />
                  <div className="font-semibold text-[11px]">Room Temp</div>
                  <div className="text-[9px] text-slate-400">Max 4 hrs limit</div>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Packaging Condition <span className="text-rose-400">*</span>
              </label>
              <select
                value={packaging}
                onChange={(e) => setPackaging(e.target.value as PackagingType)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              >
                <option value="sealed_steel_containers">Sealed Stainless Steel Pots / Chafers</option>
                <option value="foil_packed_boxes">Sealed Food-grade Foil Boxes / Meal Trays</option>
                <option value="disposable_bulk_containers">Heavy Duty Food-Grade Poly Containers</option>
                <option value="requires_volunteer_boxes">Needs Volunteer insulated transport boxes</option>
              </select>
            </div>
          </div>

          {/* AI Safety Assessment Card */}
          {safetyReport && (
            <div
              className={`p-4 rounded-2xl border text-xs space-y-3 transition ${
                safetyReport.safeToDeliver
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
                  : 'bg-rose-950/60 border-rose-500 text-rose-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {safetyReport.safeToDeliver ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                  )}
                  <div>
                    <h4 className="font-bold text-sm text-white">{safetyReport.verdictTitle}</h4>
                    <span className="text-[10px] uppercase font-mono tracking-wider opacity-90">
                      Safety Index: {safetyReport.safetyScore}/100 • Status: {safetyReport.status}
                    </span>
                  </div>
                </div>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    safetyReport.safeToDeliver
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {safetyReport.safeToDeliver ? 'DELIVERY PERMITTED' : 'DISPATCH BLOCKED'}
                </span>
              </div>

              {safetyReport.keyObservations && safetyReport.keyObservations.length > 0 && (
                <ul className="space-y-1 list-disc list-inside text-[11px] opacity-90 pl-1">
                  {safetyReport.keyObservations.map((obs, idx) => (
                    <li key={idx}>{obs}</li>
                  ))}
                </ul>
              )}

              {safetyReport.safeToDeliver ? (
                <div className="text-[11px] p-2 rounded-lg bg-emerald-900/40 border border-emerald-800 text-emerald-300">
                  <strong>Volunteer Reminder:</strong> {safetyReport.handlingReminders?.[0] || 'Keep sealed during transit.'}
                </div>
              ) : (
                <div className="text-[11px] p-2 rounded-lg bg-rose-900/40 border border-rose-800 text-rose-200">
                  <strong>Strict Policy:</strong> To protect children in orphanages and frail seniors, FoodBridge rejects food stored over 4 hours at ambient temperature. Please dispose or compost responsibly.
                </div>
              )}
            </div>
          )}
        </div>

        {/* Section 3: Pickup Location & Contact */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-5">
          <h3 className="text-sm font-bold uppercase tracking-wider text-cyan-400 border-b border-slate-800 pb-3 flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            <span>3. Pickup Address & Contact Details</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Pickup Address / Kitchen Gate <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={pickupAddress}
                onChange={(e) => setPickupAddress(e.target.value)}
                placeholder="e.g. Royal Wedding Hall, Loading Dock Gate 2, Outer Ring Road"
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Landmark for Volunteer Navigation
              </label>
              <input
                type="text"
                value={pickupLandmark}
                onChange={(e) => setPickupLandmark(e.target.value)}
                placeholder="e.g. Opposite Cisco Tech Park, Marathahalli"
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Contact Phone for Pickup Verification <span className="text-rose-400">*</span>
              </label>
              <input
                type="tel"
                value={donorPhone}
                onChange={(e) => setDonorPhone(e.target.value)}
                placeholder="+91 98450 12345"
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-400">
            A 4-digit pickup code will be generated upon posting to verify handover to the volunteer.
          </p>

          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm transition shadow-lg shadow-emerald-500/20"
          >
            Post Donation for Pickup
          </button>
        </div>
      </form>
    </div>
  );
};
