import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { FoodDonation } from '../types';
import {
  Bike,
  MapPin,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Phone,
  Building2,
  Award,
  Sparkles,
  Navigation,
  KeyRound,
  FileText,
  Check,
} from 'lucide-react';

export const VolunteerDashboardPage: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const {
    currentUser,
    donations,
    acceptDeliveryMission,
    confirmPickup,
    confirmDelivery,
    setActiveRole,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'available_missions' | 'my_active_missions' | 'completed_history'>('my_active_missions');

  // Input states for PIN verification
  const [pickupPinInput, setPickupPinInput] = useState<{ [donationId: string]: string }>({});
  const [deliveryPinInput, setDeliveryPinInput] = useState<{ [donationId: string]: string }>({});
  const [deliveryNotesInput, setDeliveryNotesInput] = useState<{ [donationId: string]: string }>({});

  // Missions waiting for a volunteer (Status: 'requested' and no volunteer assigned yet)
  const availableMissions = donations.filter((d) => d.status === 'requested');

  // Volunteer's active tasks (accepted or picked_up)
  const myActiveMissions = donations.filter(
    (d) =>
      (d.assignedVolunteerId === currentUser.id || (!d.assignedVolunteerId && d.status === 'accepted')) &&
      (d.status === 'accepted' || d.status === 'picked_up')
  );

  // Completed missions
  const completedMissions = donations.filter(
    (d) =>
      d.status === 'delivered' &&
      (d.assignedVolunteerId === currentUser.id || (currentUser.completedDeliveriesCount || 0) > 0)
  );

  const handleAccept = (donationId: string) => {
    acceptDeliveryMission(donationId, currentUser.id);
    setActiveTab('my_active_missions');
  };

  const handlePickupVerification = (donation: FoodDonation) => {
    const pin = pickupPinInput[donation.id] || donation.pickupVerificationCode || '1234';
    const res = confirmPickup(donation.id, currentUser.id, pin);
    if (!res.success) {
      showToast(res.message, 'error');
    }
  };

  const handleDeliveryVerification = (donation: FoodDonation) => {
    const pin = deliveryPinInput[donation.id] || donation.deliveryVerificationCode || '1234';
    const notes = deliveryNotesInput[donation.id] || 'Delivered hot and fresh. Clean handover verified.';
    const res = confirmDelivery(donation.id, currentUser.id, pin, notes);
    if (!res.success) {
      showToast(res.message, 'error');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <Bike className="w-3.5 h-3.5" />
            <span>Volunteer Courier Operations</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Volunteer Delivery Hub
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">
            Accept food rescue missions, pickup banquet meals, and deliver hot food directly to care homes.
          </p>
        </div>

        {/* Volunteer Stats Pill */}
        <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-center">
            <div className="text-base font-extrabold text-amber-400">
              {currentUser.volunteerPoints || 0}
            </div>
            <div className="text-[10px] text-slate-400 uppercase font-semibold">Points</div>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-center">
            <div className="text-base font-extrabold text-emerald-400">
              {currentUser.completedDeliveriesCount || 0}
            </div>
            <div className="text-[10px] text-slate-400 uppercase font-semibold">Deliveries</div>
          </div>
          <button
            onClick={() => onNavigate('rewards')}
            className="px-3 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-semibold text-xs border border-amber-500/40 transition flex items-center gap-1"
          >
            <Award className="w-4 h-4" />
            <span className="hidden sm:inline">My Badges</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-slate-800 text-xs font-semibold max-w-xl">
        <button
          onClick={() => setActiveTab('my_active_missions')}
          className={`flex-1 py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 ${
            activeTab === 'my_active_missions'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Navigation className="w-3.5 h-3.5" />
          <span>My Active Deliveries ({myActiveMissions.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('available_missions')}
          className={`flex-1 py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 ${
            activeTab === 'available_missions'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Bike className="w-3.5 h-3.5" />
          <span>Available Runs ({availableMissions.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('completed_history')}
          className={`flex-1 py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 ${
            activeTab === 'completed_history'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>History ({completedMissions.length})</span>
        </button>
      </div>

      {/* TAB 1: My Active Deliveries (Interactive Step-by-Step Delivery Flow) */}
      {activeTab === 'my_active_missions' && (
        <div className="space-y-6">
          {myActiveMissions.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
              <Bike className="w-12 h-12 text-slate-600 mx-auto" />
              <div>
                <h3 className="text-base font-bold text-white">No active deliveries in progress</h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                  Ready to be a hunger lifesaver? Check available requested runs waiting for courier pickup.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('available_missions')}
                className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs transition inline-flex items-center gap-1.5"
              >
                <span>Browse Available Runs ({availableMissions.length})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            myActiveMissions.map((donation) => {
              const isPickedUp = donation.status === 'picked_up';

              return (
                <div
                  key={donation.id}
                  className="rounded-3xl bg-slate-900 border border-amber-500/40 p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden"
                >
                  {/* Glowing header accent */}
                  <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-emerald-500 to-teal-500" />

                  {/* Top Status & Overview */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-widest text-amber-400 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                        <span>Live Mission in Progress</span>
                      </span>
                      <h2 className="text-xl font-bold text-white mt-1">{donation.foodName}</h2>
                      <div className="text-xs text-slate-400 mt-0.5">
                        {donation.quantityServings} servings • {donation.estimatedWeightKg} kg • {donation.dietType.toUpperCase()}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`px-3 py-1.5 rounded-full text-xs font-bold ${
                          isPickedUp
                            ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        }`}
                      >
                        {isPickedUp ? 'PHASE 2: IN TRANSIT TO RECIPIENT' : 'PHASE 1: HEADING TO PICKUP'}
                      </span>
                    </div>
                  </div>

                  {/* 4-Step Interactive Progress Bar */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                    <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-500/60 text-emerald-300">
                      <div className="text-xs font-bold flex items-center justify-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        <span>1. Accepted</span>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Assigned to you</div>
                    </div>

                    <div
                      className={`p-3 rounded-2xl border ${
                        isPickedUp
                          ? 'bg-emerald-950/60 border-emerald-500/60 text-emerald-300'
                          : 'bg-amber-950/60 border-amber-500 text-amber-300 animate-pulse'
                      }`}
                    >
                      <div className="text-xs font-bold flex items-center justify-center gap-1">
                        {isPickedUp ? <Check className="w-3.5 h-3.5" /> : <span>2.</span>}
                        <span>Food Pickup</span>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        {isPickedUp ? 'Completed at ' + (donation.pickedUpAt || 'Now') : 'Verify Donor PIN'}
                      </div>
                    </div>

                    <div
                      className={`p-3 rounded-2xl border ${
                        isPickedUp
                          ? 'bg-cyan-950/60 border-cyan-500 text-cyan-300 animate-pulse'
                          : 'bg-slate-800/40 border-slate-700 text-slate-500'
                      }`}
                    >
                      <div className="text-xs font-bold">3. In Transit</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Keep containers upright</div>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-800/40 border border-slate-700 text-slate-500">
                      <div className="text-xs font-bold">4. Handover & Badge</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Recipient code unlocks points</div>
                    </div>
                  </div>

                  {/* Route & Contact Details Card */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Origin (Donor) */}
                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 space-y-2">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                        <span className="flex items-center gap-1 text-emerald-400">
                          <Building2 className="w-4 h-4" />
                          <span>PICKUP ORIGIN</span>
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300">
                          Donor
                        </span>
                      </div>
                      <div className="text-sm font-bold text-white">{donation.donorOrg}</div>
                      <div className="text-xs text-slate-300 flex items-start gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span>{donation.pickupAddress} ({donation.pickupLandmark})</span>
                      </div>
                      <div className="text-xs text-slate-400 flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Donor Contact: {donation.donorPhone}</span>
                      </div>
                    </div>

                    {/* Destination (Recipient Care Home) */}
                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 space-y-2">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                        <span className="flex items-center gap-1 text-teal-400">
                          <Navigation className="w-4 h-4" />
                          <span>DROPOFF DESTINATION</span>
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-teal-950 text-teal-300">
                          Recipient
                        </span>
                      </div>
                      <div className="text-sm font-bold text-white">{donation.requestedByRecipientName}</div>
                      <div className="text-xs text-slate-300 flex items-start gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span>{donation.recipientAddress || 'Care Home Center'}</span>
                      </div>
                      <div className="text-xs text-slate-400 flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-teal-400" />
                        <span>Care Home Contact: {donation.recipientContact || 'Reception Desk'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Food Safety Reminder for Volunteer */}
                  <div className="p-3.5 rounded-2xl bg-slate-800/40 border border-slate-700 text-xs text-slate-300 flex items-center gap-3">
                    <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                    <div className="flex-1">
                      <strong>Food Handling Safe Transit:</strong> Ensure all container lids remain tightly clamped. Target direct transit without intermediate stops to preserve warmth above 60°C.
                    </div>
                  </div>

                  {/* Handover Verification Interaction Block */}
                  {!isPickedUp ? (
                    /* Phase 1 Action: Confirm Pickup */
                    <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-800 to-amber-950/40 border border-amber-500/40 space-y-4">
                      <div>
                        <h4 className="font-bold text-sm text-white flex items-center gap-2">
                          <KeyRound className="w-4 h-4 text-amber-400" />
                          <span>Step 1: Confirm Pickup with Donor</span>
                        </h4>
                        <p className="text-xs text-slate-300 mt-0.5">
                          Inspect food aroma and container seals at the donor kitchen. Ask the donor for their 4-digit pickup code or use the code below.
                        </p>
                      </div>

                      <div className="flex flex-col sm:flex-row items-center gap-3">
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                          <input
                            type="text"
                            maxLength={6}
                            placeholder={`Code: ${donation.pickupVerificationCode || '4821'}`}
                            value={pickupPinInput[donation.id] || ''}
                            onChange={(e) =>
                              setPickupPinInput({ ...pickupPinInput, [donation.id]: e.target.value })
                            }
                            className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-center tracking-widest text-sm focus:outline-none focus:border-amber-400 w-36"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              setPickupPinInput({
                                ...pickupPinInput,
                                [donation.id]: donation.pickupVerificationCode || '4821',
                              })
                            }
                            className="px-2.5 py-2 text-[11px] rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
                          >
                            Autofill Code ({donation.pickupVerificationCode})
                          </button>
                        </div>

                        <button
                          onClick={() => handlePickupVerification(donation)}
                          className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition shadow-md shadow-amber-500/20"
                        >
                          Confirm Food Picked Up →
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* Phase 2 Action: Confirm Delivery at Care Home (Triggers Badge & Points!) */
                    <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-slate-800 to-emerald-950/40 border border-emerald-500/40 space-y-4">
                      <div>
                        <h4 className="font-bold text-sm text-white flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          <span>Step 2: Confirm Delivery & Verify Handover at Care Home</span>
                        </h4>
                        <p className="text-xs text-slate-300 mt-0.5">
                          Hand over food containers to the shelter kitchen supervisor. Enter their recipient verification code to complete the run and earn your points and badges!
                        </p>
                      </div>

                      <div className="space-y-3">
                        <div className="flex flex-col sm:flex-row items-center gap-3">
                          <div className="flex items-center gap-2 w-full sm:w-auto">
                            <input
                              type="text"
                              maxLength={6}
                              placeholder={`PIN: ${donation.deliveryVerificationCode || '9153'}`}
                              value={deliveryPinInput[donation.id] || ''}
                              onChange={(e) =>
                                setDeliveryPinInput({ ...deliveryPinInput, [donation.id]: e.target.value })
                              }
                              className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-center tracking-widest text-sm focus:outline-none focus:border-emerald-400 w-36"
                            />
                            <button
                              type="button"
                              onClick={() =>
                                setDeliveryPinInput({
                                  ...deliveryPinInput,
                                  [donation.id]: donation.deliveryVerificationCode || '9153',
                                })
                              }
                              className="px-2.5 py-2 text-[11px] rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
                            >
                              Autofill Recipient PIN ({donation.deliveryVerificationCode})
                            </button>
                          </div>

                          <button
                            onClick={() => handleDeliveryVerification(donation)}
                            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs transition shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-1.5"
                          >
                            <Sparkles className="w-4 h-4" />
                            <span>Verify Handover & Earn Badges!</span>
                          </button>
                        </div>

                        <div>
                          <input
                            type="text"
                            placeholder="Handover note (e.g. Received hot by sister in-charge, 45 children fed)"
                            value={deliveryNotesInput[donation.id] || ''}
                            onChange={(e) =>
                              setDeliveryNotesInput({ ...deliveryNotesInput, [donation.id]: e.target.value })
                            }
                            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 2: Available Runs to Accept */}
      {activeTab === 'available_missions' && (
        <div className="space-y-4">
          {availableMissions.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <h3 className="text-base font-bold text-white">All requests currently assigned!</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                No care homes are currently waiting for a volunteer dispatch. Check back soon or visit Available Donations.
              </p>
              <button
                onClick={() => onNavigate('available')}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
              >
                View Available Food Listings
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {availableMissions.map((donation) => (
                <div
                  key={donation.id}
                  className="p-5 rounded-3xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 transition flex flex-col justify-between space-y-4 shadow-lg"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold uppercase tracking-wider">
                        Waiting for Delivery Volunteer
                      </span>
                      <span className="text-xs font-mono text-slate-400">{donation.availableUntil}</span>
                    </div>

                    <div>
                      <h3 className="font-bold text-white text-base leading-snug">{donation.foodName}</h3>
                      <div className="text-xs text-emerald-400 font-semibold mt-0.5">
                        {donation.quantityServings} servings • {donation.estimatedWeightKg} kg • {donation.dietType.toUpperCase()}
                      </div>
                    </div>

                    <div className="space-y-1.5 text-xs text-slate-300 pt-2 border-t border-slate-800">
                      <div className="flex items-start gap-2">
                        <span className="text-[10px] font-bold uppercase text-slate-500 shrink-0 mt-0.5">From:</span>
                        <span className="font-medium text-white">{donation.donorOrg} ({donation.pickupAddress})</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="text-[10px] font-bold uppercase text-teal-400 shrink-0 mt-0.5">To:</span>
                        <span className="font-medium text-teal-300">
                          {donation.requestedByRecipientName} ({donation.recipientAddress || 'Care Center'})
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-3">
                    <div className="text-[11px] text-amber-400 font-semibold flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>+{100 + Math.floor(donation.quantityServings / 2)} pts reward</span>
                    </div>

                    <button
                      onClick={() => handleAccept(donation.id)}
                      className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs transition shadow-md shadow-amber-500/20 flex items-center gap-1.5"
                    >
                      <Bike className="w-3.5 h-3.5" />
                      <span>Accept Delivery Mission</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: Completed History */}
      {activeTab === 'completed_history' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
            <span className="text-slate-300">
              Deliveries verified by care home supervisors earn permanent verified points and badges.
            </span>
            <button
              onClick={() => onNavigate('rewards')}
              className="text-amber-400 hover:text-amber-300 font-semibold underline underline-offset-4"
            >
              View Points Leaderboard & Badges →
            </button>
          </div>

          <div className="space-y-3">
            {completedMissions.map((donation) => (
              <div
                key={donation.id}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">{donation.foodName}</h4>
                    <div className="text-xs text-slate-400 mt-0.5">
                      Delivered to <strong className="text-white">{donation.requestedByRecipientName}</strong> at{' '}
                      {donation.deliveredAt || 'Today'}
                    </div>
                    {donation.deliveryNotes && (
                      <p className="text-[11px] text-slate-400 mt-1 italic">
                        "{donation.deliveryNotes}"
                      </p>
                    )}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-sm font-bold text-emerald-400">
                    +{100 + Math.floor(donation.quantityServings / 2)} Points
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {donation.quantityServings} meals delivered
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
