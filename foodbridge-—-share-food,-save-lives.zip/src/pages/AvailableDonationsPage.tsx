import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { FoodDonation, RecipientOrg, FoodDietType } from '../types';
import { requestAiMatches, AiMatchResult } from '../services/geminiService';
import {
  UtensilsCrossed,
  Search,
  Filter,
  Sparkles,
  MapPin,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Building2,
  Bike,
  Heart,
  ChevronRight,
  Loader2,
  Check,
} from 'lucide-react';

export const AvailableDonationsPage: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const { donations, recipients, currentUser, requestDonation, switchPersona, setActiveRole, showToast } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDiet, setSelectedDiet] = useState<'all' | FoodDietType>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'available' | 'requested' | 'accepted' | 'delivered'>('all');

  // Requesting Modal State
  const [requestModalDonation, setRequestModalDonation] = useState<FoodDonation | null>(null);
  const [selectedRecipientId, setSelectedRecipientId] = useState<string>(
    currentUser.roles.includes('recipient') ? currentUser.id : recipients[0]?.id || ''
  );

  // Gemini AI Matchmaker State
  const [isAiMatching, setIsAiMatching] = useState(false);
  const [aiMatchData, setAiMatchData] = useState<AiMatchResult | null>(null);
  const [matchingDonationId, setMatchingDonationId] = useState<string | null>(null);

  // Filtered donations
  const filteredDonations = donations.filter((d) => {
    const matchesSearch =
      d.foodName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.pickupAddress.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.donorOrg.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDiet = selectedDiet === 'all' || d.dietType === selectedDiet;
    const matchesStatus = statusFilter === 'all' || d.status === statusFilter;

    return matchesSearch && matchesDiet && matchesStatus;
  });

  const handleOpenRequestModal = (donation: FoodDonation) => {
    setRequestModalDonation(donation);
    // If current user is already a recipient, pre-select them
    const matchingRec = recipients.find((r) => r.name === currentUser.organizationName);
    if (matchingRec) {
      setSelectedRecipientId(matchingRec.id);
    } else {
      setSelectedRecipientId(recipients[0]?.id || '');
    }
  };

  const handleConfirmRequest = () => {
    if (!requestModalDonation) return;

    const chosenOrg = recipients.find((r) => r.id === selectedRecipientId);
    requestDonation(requestModalDonation.id, selectedRecipientId);
    setRequestModalDonation(null);
  };

  const handleRunAiMatch = async (donation: FoodDonation) => {
    setIsAiMatching(true);
    setMatchingDonationId(donation.id);
    try {
      const result = await requestAiMatches(donation, recipients);
      setAiMatchData(result);
      showToast('Gemini AI evaluated optimal recipient matches.', 'success');
    } catch {
      showToast('Generated matches using heuristic engine.', 'info');
    } finally {
      setIsAiMatching(false);
    }
  };

  const getStatusBadge = (status: FoodDonation['status']) => {
    switch (status) {
      case 'available':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>Available for Request</span>
          </span>
        );
      case 'requested':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            <span>Requested • Awaiting Volunteer</span>
          </span>
        );
      case 'accepted':
      case 'picked_up':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center gap-1">
            <Bike className="w-3 h-3 text-cyan-400" />
            <span>In Transit With Volunteer</span>
          </span>
        );
      case 'delivered':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>Delivered & Verified</span>
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <UtensilsCrossed className="w-3.5 h-3.5" />
            <span>Surplus Food Directory</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            Available Food Donations
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">
            Browse wholesome banquet food ready for immediate rescue by orphanages, elder homes, and shelters.
          </p>
        </div>

        {/* Quick action buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setActiveRole('donor');
              onNavigate('donate');
            }}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition shadow-md shadow-emerald-600/20"
          >
            + Post New Donation
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by food dish, banquet hall, or area..."
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Diet Filter */}
          <div className="flex items-center gap-1 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
            {(['all', 'veg', 'non_veg'] as const).map((diet) => (
              <button
                key={diet}
                onClick={() => setSelectedDiet(diet)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition shrink-0 ${
                  selectedDiet === diet
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {diet === 'all' ? 'All Diets' : diet === 'veg' ? 'Pure Veg' : 'Non-Veg'}
              </button>
            ))}
          </div>
        </div>

        {/* Status Pill Filters */}
        <div className="flex items-center gap-2 overflow-x-auto text-xs pt-1 border-t border-slate-800/80">
          <span className="text-slate-400 text-[11px] shrink-0 font-medium">Status:</span>
          {(['all', 'available', 'requested', 'accepted', 'delivered'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition shrink-0 ${
                statusFilter === st
                  ? 'bg-slate-700 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {st === 'all'
                ? 'All'
                : st === 'available'
                ? 'Available'
                : st === 'requested'
                ? 'Requested'
                : st === 'accepted'
                ? 'In Transit'
                : 'Delivered'}
            </button>
          ))}
        </div>
      </div>

      {/* AI Match Recommendation Banner (If generated) */}
      {aiMatchData && matchingDonationId && (
        <div className="p-6 rounded-3xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/60 border border-emerald-500/40 space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-400">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Gemini AI Smart Recipient Match Report</span>
              </div>
              <p className="text-slate-300 text-xs mt-1 font-medium">
                {aiMatchData.aiMatchSummary}
              </p>
            </div>
            <button
              onClick={() => {
                setAiMatchData(null);
                setMatchingDonationId(null);
              }}
              className="text-xs text-slate-400 hover:text-white"
            >
              Close AI Analysis ✕
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {aiMatchData.matches.map((m) => {
              const recOrg = recipients.find((r) => r.id === m.recipientId);
              if (!recOrg) return null;

              return (
                <div
                  key={m.recipientId}
                  className="p-3.5 rounded-2xl bg-slate-900/90 border border-emerald-500/30 space-y-2 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-white truncate">{recOrg.name}</span>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px]">
                        {m.matchScore}% Match
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {recOrg.capacity} residents • {recOrg.distanceKm} km away
                    </div>
                    <p className="text-xs text-slate-300 mt-2 italic leading-relaxed">
                      "{m.reasoning}"
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      requestDonation(matchingDonationId, m.recipientId);
                      setAiMatchData(null);
                      setMatchingDonationId(null);
                    }}
                    className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition flex items-center justify-center gap-1.5 mt-2"
                  >
                    <span>Request for {recOrg.name}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Donations Grid */}
      {filteredDonations.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <UtensilsCrossed className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-white">No donations found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Try adjusting your search criteria or switch status filter to view all listings.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDonations.map((donation) => {
            const isAvailable = donation.status === 'available';
            const isRequested = donation.status === 'requested';
            const isInTransit = donation.status === 'accepted' || donation.status === 'picked_up';
            const isDelivered = donation.status === 'delivered';

            return (
              <div
                key={donation.id}
                className="rounded-3xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between overflow-hidden shadow-lg"
              >
                {/* Card Top */}
                <div className="p-5 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    {getStatusBadge(donation.status)}
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        donation.dietType === 'veg'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}
                    >
                      {donation.dietType === 'veg' ? 'Veg' : 'Non-Veg'}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-white leading-snug line-clamp-2">
                      {donation.foodName}
                    </h3>
                    <div className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-slate-500" />
                      <span className="font-medium text-slate-300 truncate">{donation.donorOrg}</span>
                    </div>
                  </div>

                  {/* Servings & Weight Stats */}
                  <div className="grid grid-cols-3 gap-2 py-2 border-y border-slate-800/80 text-center">
                    <div>
                      <div className="text-base font-extrabold text-emerald-400">
                        {donation.quantityServings}
                      </div>
                      <div className="text-[10px] text-slate-400 uppercase">Servings</div>
                    </div>
                    <div>
                      <div className="text-base font-extrabold text-amber-400">
                        {donation.estimatedWeightKg} kg
                      </div>
                      <div className="text-[10px] text-slate-400 uppercase">Weight</div>
                    </div>
                    <div>
                      <div className="text-base font-extrabold text-teal-400">
                        {donation.numberOfContainers}
                      </div>
                      <div className="text-[10px] text-slate-400 uppercase">Pots/Boxes</div>
                    </div>
                  </div>

                  {/* Safety & Time Indicators */}
                  <div className="space-y-1.5 text-xs text-slate-300">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>{donation.prepTime} • {donation.availableUntil}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span className="truncate">{donation.pickupAddress}</span>
                    </div>
                    <div className="flex items-center gap-2 text-emerald-400 font-medium">
                      <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                      <span>Safety Score: {donation.safetyScore}/100 verified</span>
                    </div>
                  </div>

                  {donation.description && (
                    <p className="text-xs text-slate-400 line-clamp-2 italic bg-slate-800/40 p-2.5 rounded-xl">
                      "{donation.description}"
                    </p>
                  )}

                  {/* If already requested/in transit, show recipient */}
                  {(isRequested || isInTransit || isDelivered) && donation.requestedByRecipientName && (
                    <div className="p-3 rounded-xl bg-teal-950/40 border border-teal-800/60 text-xs text-teal-200">
                      <div className="text-[10px] uppercase font-bold text-teal-400">Requested For:</div>
                      <div className="font-semibold text-white mt-0.5">{donation.requestedByRecipientName}</div>
                      {donation.assignedVolunteerName && (
                        <div className="text-[11px] text-amber-300 mt-1 flex items-center gap-1">
                          <Bike className="w-3 h-3" />
                          <span>Courier: {donation.assignedVolunteerName}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Card Actions */}
                <div className="p-4 bg-slate-950/50 border-t border-slate-800 flex flex-col gap-2">
                  {isAvailable && (
                    <>
                      <div className="grid grid-cols-2 gap-2">
                        {/* Gemini AI Match Button */}
                        <button
                          onClick={() => handleRunAiMatch(donation)}
                          disabled={isAiMatching && matchingDonationId === donation.id}
                          className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-emerald-300 text-xs font-semibold transition flex items-center justify-center gap-1.5"
                        >
                          {isAiMatching && matchingDonationId === donation.id ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                          )}
                          <span>AI Match</span>
                        </button>

                        {/* Request Button */}
                        <button
                          onClick={() => handleOpenRequestModal(donation)}
                          className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20"
                        >
                          <span>Request Food</span>
                        </button>
                      </div>
                    </>
                  )}

                  {isRequested && (
                    <button
                      onClick={() => {
                        setActiveRole('volunteer');
                        onNavigate('volunteer');
                      }}
                      className="w-full py-2.5 px-3 rounded-xl bg-amber-600/20 hover:bg-amber-600 border border-amber-500/30 text-amber-200 hover:text-white text-xs font-semibold transition flex items-center justify-center gap-1.5"
                    >
                      <Bike className="w-3.5 h-3.5" />
                      <span>Deliver as Volunteer →</span>
                    </button>
                  )}

                  {isInTransit && (
                    <button
                      onClick={() => {
                        setActiveRole('volunteer');
                        onNavigate('volunteer');
                      }}
                      className="w-full py-2.5 px-3 rounded-xl bg-cyan-600/20 hover:bg-cyan-600 border border-cyan-500/30 text-cyan-200 hover:text-white text-xs font-semibold transition flex items-center justify-center gap-1.5"
                    >
                      <span>Track In-Progress Delivery →</span>
                    </button>
                  )}

                  {isDelivered && (
                    <div className="text-center py-1.5 text-xs text-slate-400 flex items-center justify-center gap-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>Successfully Handed Over at {donation.deliveredAt || 'Earlier'}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Recipient Request Confirmation Modal */}
      {requestModalDonation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700 p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-lg text-white">Confirm Food Request</h3>
                <p className="text-xs text-slate-400">
                  Volunteers will be immediately alerted to collect this meal.
                </p>
              </div>
              <button
                onClick={() => setRequestModalDonation(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-1 text-xs">
              <div className="font-bold text-white text-sm">{requestModalDonation.foodName}</div>
              <div className="text-emerald-400 font-semibold">
                {requestModalDonation.quantityServings} servings • {requestModalDonation.estimatedWeightKg} kg
              </div>
              <div className="text-slate-400">Pickup from: {requestModalDonation.donorOrg}</div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Select Requesting Care Home / Shelter:
              </label>
              <select
                value={selectedRecipientId}
                onChange={(e) => setSelectedRecipientId(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              >
                {recipients.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name} ({r.capacity} residents • {r.address})
                  </option>
                ))}
              </select>
            </div>

            <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800 text-[11px] text-emerald-300 space-y-1">
              <div className="font-bold uppercase tracking-wider">Handover Verification Note:</div>
              <div>
                When the delivery volunteer arrives at your home, provide the recipient 4-digit code (
                <strong>{requestModalDonation.deliveryVerificationCode}</strong>) to confirm safe meal receipt.
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setRequestModalDonation(null)}
                className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmRequest}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs hover:from-emerald-400 hover:to-teal-400 transition"
              >
                Confirm Food Request
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
