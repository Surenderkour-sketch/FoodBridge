import { FoodDonation, RecipientOrg, ImpactStats } from '../types';

export interface AiMatchResult {
  matches: {
    recipientId: string;
    matchScore: number;
    priorityTier: 'High' | 'Medium' | 'Low';
    reasoning: string;
    dietaryFit: 'High' | 'Moderate';
    recommendationTag: string;
  }[];
  aiMatchSummary: string;
}

export interface FoodSafetyReport {
  safeToDeliver: boolean;
  safetyScore: number;
  status: 'APPROVED' | 'CAUTION_REQUIRED' | 'UNSAFE_REJECTED';
  verdictTitle: string;
  keyObservations: string[];
  handlingReminders: string[];
  safeWindowRemainingHours: number;
  recipientAdvisory: string;
}

export interface HandlingRemindersResult {
  reminders: string[];
  temperatureGuidelines: string;
  deliveryWindowTip: string;
}

export interface ImpactSummaryResult {
  headline: string;
  summary: string;
  socialQuote: string;
  environmentalImpactText: string;
}

export async function requestAiMatches(
  donation: Partial<FoodDonation>,
  recipients: RecipientOrg[]
): Promise<AiMatchResult> {
  try {
    const res = await fetch('/api/gemini/suggest-matches', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ donation, recipients }),
    });
    if (!res.ok) throw new Error('API request failed');
    return await res.json();
  } catch (error) {
    console.warn('Fallback to local match engine:', error);
    // Deterministic fallback matching
    const sorted = [...recipients].map((r, i) => ({
      recipientId: r.id,
      matchScore: Math.min(98, Math.max(68, 96 - i * 9 + (r.dietaryPreference === donation.dietType ? 5 : 0))),
      priorityTier: (i === 0 ? 'High' : i === 1 ? 'High' : 'Medium') as 'High' | 'Medium' | 'Low',
      reasoning: `Matches estimated capacity of ${r.capacity} people with ${donation.dietType || 'fresh'} food requirements at ${r.distanceKm} km.`,
      dietaryFit: (r.dietaryPreference === donation.dietType || r.dietaryPreference === 'all' ? 'High' : 'Moderate') as 'High' | 'Moderate',
      recommendationTag: i === 0 ? 'Best Match' : 'Capacity Match',
    }));

    return {
      matches: sorted,
      aiMatchSummary: `Rescuing ${donation.foodName || 'this surplus'} provides ${donation.quantityServings || 50} warm meals to local community care centers.`,
    };
  }
}

export async function checkFoodSafetyWithAi(params: {
  foodName: string;
  foodType: string;
  prepTimeHoursAgo: number;
  storageCondition: string;
  tempEstimate: string;
  packaging: string;
  isPerishable: boolean;
}): Promise<FoodSafetyReport> {
  try {
    const res = await fetch('/api/gemini/food-safety-check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) throw new Error('API request failed');
    return await res.json();
  } catch (error) {
    console.warn('Fallback to local safety rule validator:', error);
    const hours = Number(params.prepTimeHoursAgo) || 2;
    const isAmbient = params.storageCondition.includes('room_temp') || params.storageCondition.includes('ambient');
    const isDangerZone = hours >= 4 && isAmbient;

    if (isDangerZone) {
      return {
        safeToDeliver: false,
        safetyScore: 32,
        status: 'UNSAFE_REJECTED',
        verdictTitle: 'Exceeds Safe Ambient Time (Food Danger Zone)',
        keyObservations: [
          `Prepared ${hours} hours ago and kept at ambient room temperature without continuous heating or chilling.`,
          'Bacterial pathogens (e.g., Bacillus cereus, Staph) multiply rapidly between 5°C and 60°C after 4 hours.',
          'FoodBridge safety guidelines strictly prohibit delivering compromised food to vulnerable children or seniors.',
        ],
        handlingReminders: [
          'Do NOT dispatch volunteers for this item.',
          'Food must be repurposed for certified organic composting or disposed safely.',
        ],
        safeWindowRemainingHours: 0,
        recipientAdvisory: 'Unsafe for consumption. Do not accept.',
      };
    }

    const isCaution = hours > 2.5;
    return {
      safeToDeliver: true,
      safetyScore: isCaution ? 78 : 96,
      status: isCaution ? 'CAUTION_REQUIRED' : 'APPROVED',
      verdictTitle: isCaution ? 'Safe with Express Transit Required' : 'Certified Safe For Immediate Dispatch',
      keyObservations: [
        `Prepared ${hours} hours ago within approved food recovery window.`,
        `Storage method (${params.storageCondition.replace(/_/g, ' ')}) complies with hygiene standard.`,
        'Food containers are sealed and protected from external airborne contaminants.',
      ],
      handlingReminders: [
        'Keep transport container lids tightly sealed during motorbike or car journey.',
        'Deliver directly to recipient kitchen without transit delays.',
        'Inform care home cook to verify aroma and reheat to above 74°C before serving.',
      ],
      safeWindowRemainingHours: Math.max(1, Math.round(5 - hours)),
      recipientAdvisory: 'Safe to serve upon thermal verification by care home supervisor.',
    };
  }
}

export async function requestHandlingReminders(params: {
  foodName: string;
  foodType: string;
  quantity: string | number;
  transitMode?: string;
}): Promise<HandlingRemindersResult> {
  try {
    const res = await fetch('/api/gemini/handling-reminders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) throw new Error('API request failed');
    return await res.json();
  } catch {
    return {
      reminders: [
        'Keep all gravy and soup containers upright with secure lid locks.',
        'Protect food from direct sunlight during motorbike or vehicle transit.',
        'Use clean sanitizer before touching handles or handover boxes.',
        'Verify packaging integrity and food aroma with the recipient on arrival.',
      ],
      temperatureGuidelines: 'Keep hot items above 60°C (140°F) or refrigerated perishables below 5°C (41°F).',
      deliveryWindowTip: 'Complete delivery within 45 minutes of pickup for peak freshness.',
    };
  }
}

export async function requestImpactSummary(metrics: ImpactStats): Promise<ImpactSummaryResult> {
  try {
    const res = await fetch('/api/gemini/impact-summary', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ metrics }),
    });
    if (!res.ok) throw new Error('API request failed');
    return await res.json();
  } catch {
    return {
      headline: 'Connecting Surplus Tables to Empty Plates with Dignity',
      summary: `Our community of ${metrics.activeVolunteers} selfless volunteers has rescued ${metrics.kgRescued.toLocaleString()} kg of banquet food across ${metrics.completedDeliveries} verified missions, delivering ${metrics.mealsDelivered.toLocaleString()} nutritious meals to children and elderly residents.`,
      socialQuote: '"Every meal rescued is a promise kept: that no banquet is wasted while a shelter neighbor goes hungry."',
      environmentalImpactText: `By diverting ${metrics.kgRescued.toLocaleString()} kg of food from landfills, our network has prevented an estimated ${(metrics.kgRescued * 2.5).toFixed(0)} kg of greenhouse gas emissions (CO₂e).`,
    };
  }
}
