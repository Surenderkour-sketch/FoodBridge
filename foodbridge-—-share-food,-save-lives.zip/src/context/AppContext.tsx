import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  UserRole,
  FoodDonation,
  RecipientOrg,
  VolunteerBadge,
  ImpactStats,
} from '../types';
import {
  getStoredUsers,
  saveUsers,
  getStoredCurrentUser,
  saveCurrentUser,
  getStoredDonations,
  saveDonations,
  getStoredRecipients,
  saveRecipients,
  getStoredImpact,
  saveImpact,
  resetAllToDefaults,
  ALL_BADGES,
  INITIAL_USERS,
} from '../data/mockData';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title?: string;
  message: string;
}

export interface AwardCelebration {
  volunteerName: string;
  badgeAwarded?: VolunteerBadge;
  pointsEarned: number;
  mealsDelivered: number;
  recipientName: string;
}

interface AppContextType {
  currentUser: User;
  users: User[];
  activeRole: UserRole;
  donations: FoodDonation[];
  recipients: RecipientOrg[];
  impactStats: ImpactStats;
  badges: VolunteerBadge[];
  toasts: ToastMessage[];
  awardCelebration: AwardCelebration | null;
  dismissCelebration: () => void;
  showToast: (message: string, type?: ToastMessage['type'], title?: string) => void;
  switchPersona: (userId: string) => void;
  setActiveRole: (role: UserRole) => void;
  registerUser: (userData: Partial<User>) => User;
  addDonation: (data: Partial<FoodDonation>) => FoodDonation;
  requestDonation: (donationId: string, recipientId: string) => boolean;
  acceptDeliveryMission: (donationId: string, volunteerId: string) => boolean;
  confirmPickup: (donationId: string, volunteerId: string, pin: string) => { success: boolean; message: string };
  confirmDelivery: (donationId: string, volunteerId: string, pin: string, notes?: string) => { success: boolean; message: string };
  resetDemoData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(getStoredUsers);
  const [currentUser, setCurrentUser] = useState<User>(getStoredCurrentUser);
  const [donations, setDonations] = useState<FoodDonation[]>(getStoredDonations);
  const [recipients, setRecipients] = useState<RecipientOrg[]>(getStoredRecipients);
  const [impactStats, setImpactStats] = useState<ImpactStats>(getStoredImpact);
  const [badges] = useState<VolunteerBadge[]>(ALL_BADGES);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [awardCelebration, setAwardCelebration] = useState<AwardCelebration | null>(null);

  // Sync state changes to localStorage
  useEffect(() => {
    saveUsers(users);
  }, [users]);

  useEffect(() => {
    saveCurrentUser(currentUser);
  }, [currentUser]);

  useEffect(() => {
    saveDonations(donations);
  }, [donations]);

  useEffect(() => {
    saveRecipients(recipients);
  }, [recipients]);

  useEffect(() => {
    saveImpact(impactStats);
  }, [impactStats]);

  const showToast = (message: string, type: ToastMessage['type'] = 'info', title?: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type, title }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const dismissCelebration = () => setAwardCelebration(null);

  const switchPersona = (userId: string) => {
    const target = users.find((u) => u.id === userId);
    if (target) {
      setCurrentUser(target);
      showToast(`Switched account to ${target.name} (${target.activeRole.toUpperCase()})`, 'success');
    }
  };

  const setActiveRole = (role: UserRole) => {
    // If user doesn't already have this role, add it! (Supporting dual role as requested: "A person can be both a donor and a volunteer")
    const updatedRoles = currentUser.roles.includes(role)
      ? currentUser.roles
      : [...currentUser.roles, role];

    const updatedUser = {
      ...currentUser,
      roles: updatedRoles,
      activeRole: role,
    };

    setCurrentUser(updatedUser);
    setUsers((prev) => prev.map((u) => (u.id === updatedUser.id ? updatedUser : u)));
    showToast(`Switched active mode to ${role.charAt(0).toUpperCase() + role.slice(1)}`, 'info');
  };

  const registerUser = (userData: Partial<User>): User => {
    const newId = `user_${Date.now()}`;
    const roles: UserRole[] = userData.roles && userData.roles.length > 0
      ? userData.roles
      : [userData.activeRole || 'volunteer'];

    const newUser: User = {
      id: newId,
      name: userData.name || 'Anonymous User',
      email: userData.email || `user_${Date.now()}@example.com`,
      phone: userData.phone || '+91 98000 00000',
      roles: roles,
      activeRole: userData.activeRole || roles[0],
      organizationName: userData.organizationName || '',
      organizationType: userData.organizationType || 'individual',
      address: userData.address || 'Central City Area',
      city: userData.city || 'Bengaluru',
      vehicleType: userData.vehicleType || 'two_wheeler',
      volunteerPoints: 0,
      completedDeliveriesCount: 0,
      badges: [],
      recipientCapacity: userData.recipientCapacity || 50,
      dietaryPreference: userData.dietaryPreference || 'all',
      isVerifiedOrg: userData.activeRole === 'recipient',
    };

    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    setCurrentUser(newUser);

    // If recipient registered, also register them in the recipient directory
    if (roles.includes('recipient') && userData.organizationName) {
      const newRecOrg: RecipientOrg = {
        id: `rec_org_${Date.now()}`,
        name: userData.organizationName,
        type: (userData.organizationType as any) || 'orphanage',
        capacity: userData.recipientCapacity || 50,
        currentNeed: `Needs daily meals for ${userData.recipientCapacity || 50} residents.`,
        dietaryPreference: (userData.dietaryPreference as any) || 'all',
        address: userData.address || 'City Center',
        contactPerson: userData.name || 'Manager',
        phone: userData.phone || '+91 98000 00000',
        distanceKm: 2.5,
        verified: true,
      };
      setRecipients((prev) => [...prev, newRecOrg]);
    }

    showToast(`Welcome ${newUser.name}! Registered successfully.`, 'success');
    return newUser;
  };

  const addDonation = (data: Partial<FoodDonation>): FoodDonation => {
    const pickupPin = Math.floor(1000 + Math.random() * 9000).toString();
    const deliveryPin = Math.floor(1000 + Math.random() * 9000).toString();

    const newDonation: FoodDonation = {
      id: `don_${Date.now()}`,
      foodName: data.foodName || 'Surplus Meal Package',
      category: data.category || 'wedding_banquet',
      dietType: data.dietType || 'veg',
      quantityServings: Number(data.quantityServings) || 50,
      estimatedWeightKg: Number(data.estimatedWeightKg) || 20,
      numberOfContainers: Number(data.numberOfContainers) || 2,
      description: data.description || 'Nutritious surplus food ready for immediate pickup.',
      prepTime: data.prepTime || 'Prepared recently',
      prepTimeHoursAgo: Number(data.prepTimeHoursAgo) || 1,
      availableUntil: data.availableUntil || 'Valid for 4 hours',
      storageCondition: data.storageCondition || 'hot_maintained',
      packaging: data.packaging || 'sealed_steel_containers',
      donorId: currentUser.id,
      donorName: currentUser.name,
      donorOrg: currentUser.organizationName || 'Generous Donor',
      donorPhone: currentUser.phone,
      pickupAddress: data.pickupAddress || currentUser.address,
      pickupLandmark: data.pickupLandmark || 'Near Main Entrance',
      pickupCity: data.pickupCity || currentUser.city,
      pickupPinCode: data.pickupPinCode || '560001',
      status: 'available',
      createdAt: new Date().toISOString(),
      isSafetyApproved: data.isSafetyApproved ?? true,
      safetyScore: data.safetyScore ?? 92,
      safetyNotes: data.safetyNotes || 'Safety verified under standard hygiene checklist.',
      allergenInfo: data.allergenInfo || 'None specified',
      pickupVerificationCode: pickupPin,
      deliveryVerificationCode: deliveryPin,
    };

    setDonations((prev) => [newDonation, ...prev]);
    showToast(`Donation posted! Ready for recipient requests. Pickup PIN: ${pickupPin}`, 'success', 'Food Listed');
    return newDonation;
  };

  const requestDonation = (donationId: string, recipientId: string): boolean => {
    const recOrg = recipients.find((r) => r.id === recipientId);
    const recName = recOrg?.name || currentUser.organizationName || currentUser.name;
    const recAddr = recOrg?.address || currentUser.address;
    const recPhone = recOrg?.phone || currentUser.phone;

    setDonations((prev) =>
      prev.map((don) => {
        if (don.id === donationId) {
          return {
            ...don,
            status: 'requested',
            requestedByRecipientId: recipientId,
            requestedByRecipientName: recName,
            recipientAddress: recAddr,
            recipientContact: `${recName} (${recPhone})`,
          };
        }
        return don;
      })
    );

    showToast(`Food requested for ${recName}! Volunteers notified for pickup.`, 'success', 'Request Sent');
    return true;
  };

  const acceptDeliveryMission = (donationId: string, volunteerId: string): boolean => {
    const vol = users.find((u) => u.id === volunteerId) || currentUser;

    setDonations((prev) =>
      prev.map((don) => {
        if (don.id === donationId) {
          return {
            ...don,
            status: 'accepted',
            assignedVolunteerId: vol.id,
            assignedVolunteerName: vol.name,
            assignedVolunteerPhone: vol.phone,
          };
        }
        return don;
      })
    );

    showToast(`Mission accepted! Please head to donor pickup location.`, 'success', 'Delivery Assigned');
    return true;
  };

  const confirmPickup = (
    donationId: string,
    volunteerId: string,
    pin: string
  ): { success: boolean; message: string } => {
    const donation = donations.find((d) => d.id === donationId);
    if (!donation) {
      return { success: false, message: 'Donation not found' };
    }

    // Check PIN: accept exact match or allow demo override '1234'
    const expectedPin = donation.pickupVerificationCode || '1234';
    if (pin.trim() !== expectedPin && pin.trim() !== '1234') {
      return {
        success: false,
        message: `Incorrect Pickup PIN. (Hint: Donor's code is ${expectedPin} or use demo bypass '1234')`,
      };
    }

    setDonations((prev) =>
      prev.map((d) => {
        if (d.id === donationId) {
          return {
            ...d,
            status: 'picked_up',
            pickedUpAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
        }
        return d;
      })
    );

    showToast('Pickup verified! Food collected securely. Head to recipient location.', 'success', 'Food Picked Up');
    return { success: true, message: 'Pickup confirmed' };
  };

  const confirmDelivery = (
    donationId: string,
    volunteerId: string,
    pin: string,
    notes?: string
  ): { success: boolean; message: string } => {
    const donation = donations.find((d) => d.id === donationId);
    if (!donation) {
      return { success: false, message: 'Donation not found' };
    }

    const expectedPin = donation.deliveryVerificationCode || '9999';
    if (pin.trim() !== expectedPin && pin.trim() !== '9999' && pin.trim() !== '1234') {
      return {
        success: false,
        message: `Incorrect Delivery PIN. (Recipient's code is ${expectedPin} or use demo code '1234')`,
      };
    }

    const volunteer = users.find((u) => u.id === (donation.assignedVolunteerId || volunteerId)) || currentUser;

    // Points calculation: 100 base + 1 point per 2 servings
    const pointsEarned = 100 + Math.floor(donation.quantityServings / 2);
    const updatedDeliveries = (volunteer.completedDeliveriesCount || 0) + 1;
    const updatedPoints = (volunteer.volunteerPoints || 0) + pointsEarned;

    // Check newly earned badges
    const existingBadges = volunteer.badges || [];
    const newBadgesList = [...existingBadges];
    let newlyAwardedBadge: VolunteerBadge | undefined;

    if (!newBadgesList.includes('badge_first_mile') && updatedDeliveries >= 1) {
      newBadgesList.push('badge_first_mile');
      newlyAwardedBadge = ALL_BADGES.find((b) => b.id === 'badge_first_mile');
    } else if (!newBadgesList.includes('badge_community_guardian') && updatedDeliveries >= 5) {
      newBadgesList.push('badge_community_guardian');
      newlyAwardedBadge = ALL_BADGES.find((b) => b.id === 'badge_community_guardian');
    } else if (!newBadgesList.includes('badge_feast_champion') && donation.quantityServings >= 70) {
      newBadgesList.push('badge_feast_champion');
      newlyAwardedBadge = ALL_BADGES.find((b) => b.id === 'badge_feast_champion');
    }

    // Update volunteer in users list
    const updatedVolunteer: User = {
      ...volunteer,
      completedDeliveriesCount: updatedDeliveries,
      volunteerPoints: updatedPoints,
      badges: newBadgesList,
    };

    setUsers((prev) => prev.map((u) => (u.id === updatedVolunteer.id ? updatedVolunteer : u)));
    if (currentUser.id === updatedVolunteer.id) {
      setCurrentUser(updatedVolunteer);
    }

    // Update donation status
    setDonations((prev) =>
      prev.map((d) => {
        if (d.id === donationId) {
          return {
            ...d,
            status: 'delivered',
            deliveredAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            deliveryNotes: notes || 'Delivered hot and intact. Recipient verified condition.',
          };
        }
        return d;
      })
    );

    // Update impact stats
    const updatedImpact: ImpactStats = {
      mealsDelivered: impactStats.mealsDelivered + donation.quantityServings,
      kgRescued: impactStats.kgRescued + donation.estimatedWeightKg,
      completedDeliveries: impactStats.completedDeliveries + 1,
      activeVolunteers: impactStats.activeVolunteers,
      careHomesSupported: impactStats.careHomesSupported,
      co2SavedKg: impactStats.co2SavedKg + Math.round(donation.estimatedWeightKg * 2.5),
    };
    setImpactStats(updatedImpact);

    // Trigger celebration modal
    setAwardCelebration({
      volunteerName: updatedVolunteer.name,
      badgeAwarded: newlyAwardedBadge,
      pointsEarned,
      mealsDelivered: donation.quantityServings,
      recipientName: donation.requestedByRecipientName || 'Care Home',
    });

    showToast(
      `Delivery verified! +${pointsEarned} points awarded${newlyAwardedBadge ? ` & "${newlyAwardedBadge.name}" badge earned!` : '!'}`,
      'success',
      'Mission Accomplished 🎉'
    );

    return { success: true, message: 'Delivery verified successfully!' };
  };

  const resetDemoData = () => {
    resetAllToDefaults();
    setUsers(INITIAL_USERS);
    setCurrentUser(INITIAL_USERS[4]); // Rahul Sharma
    setDonations(getStoredDonations());
    setRecipients(getStoredRecipients());
    setImpactStats(getStoredImpact());
    showToast('Reset all data to fresh demo state.', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        activeRole: currentUser.activeRole,
        donations,
        recipients,
        impactStats,
        badges,
        toasts,
        awardCelebration,
        dismissCelebration,
        showToast,
        switchPersona,
        setActiveRole,
        registerUser,
        addDonation,
        requestDonation,
        acceptDeliveryMission,
        confirmPickup,
        confirmDelivery,
        resetDemoData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
