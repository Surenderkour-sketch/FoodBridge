import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ToastContainer } from './components/ToastContainer';
import { CelebrationModal } from './components/CelebrationModal';
import { HomePage } from './pages/HomePage';
import { AvailableDonationsPage } from './pages/AvailableDonationsPage';
import { DonateFoodPage } from './pages/DonateFoodPage';
import { VolunteerDashboardPage } from './pages/VolunteerDashboardPage';
import { RewardsPage } from './pages/RewardsPage';
import { ImpactDashboardPage } from './pages/ImpactDashboardPage';
import { FoodSafetyPage } from './pages/FoodSafetyPage';
import { AuthPage } from './pages/AuthPage';

function AppContent() {
  const [activeTab, setActiveTab] = useState<string>('home');

  const renderPage = () => {
    switch (activeTab) {
      case 'home':
        return <HomePage onNavigate={setActiveTab} />;
      case 'available':
        return <AvailableDonationsPage onNavigate={setActiveTab} />;
      case 'donate':
        return <DonateFoodPage onNavigate={setActiveTab} />;
      case 'volunteer':
        return <VolunteerDashboardPage onNavigate={setActiveTab} />;
      case 'rewards':
        return <RewardsPage onNavigate={setActiveTab} />;
      case 'impact':
        return <ImpactDashboardPage onNavigate={setActiveTab} />;
      case 'safety':
        return <FoodSafetyPage />;
      case 'auth':
        return <AuthPage onNavigate={setActiveTab} />;
      default:
        return <HomePage onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="flex-1">
        {renderPage()}
      </main>

      <Footer onNavigate={setActiveTab} />
      <CelebrationModal onNavigateToRewards={() => setActiveTab('rewards')} />
      <ToastContainer />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
