export type UserRole = 'donor' | 'recipient' | 'volunteer';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  roles: UserRole[]; // Can be donor AND volunteer
  activeRole: UserRole;
  organizationName?: string;
  organizationType?: 'wedding_hall' | 'hotel' | 'restaurant' | 'caterer' | 'home' | 'orphanage' | 'old_age_home' | 'homeless_shelter' | 'community_kitchen' | 'individual';
  address: string;
  city: string;
  avatarUrl?: string;
  // Volunteer specific fields
  vehicleType?: 'two_wheeler' | 'car' | 'auto_rickshaw' | 'bicycle' | 'van';
  volunteerPoints?: number;
  badges?: string[];
  completedDeliveriesCount?: number;
  // Recipient specific fields
  recipientCapacity?: number;
  dietaryPreference?: 'all' | 'veg' | 'non_veg' | 'jain';
  isVerifiedOrg?: boolean;
}

export type FoodDietType = 'veg' | 'non_veg' | 'vegan' | 'jain';
export type FoodCategory = 'wedding_banquet' | 'hotel_buffet' | 'restaurant_meals' | 'event_surplus' | 'home_cooked' | 'packaged_groceries' | 'bakery';
export type StorageCondition = 'hot_maintained' | 'refrigerated' | 'room_temp_ambient';
export type PackagingType = 'sealed_steel_containers' | 'foil_packed_boxes' | 'disposable_bulk_containers' | 'requires_volunteer_boxes';

export type DonationStatus = 'available' | 'requested' | 'accepted' | 'picked_up' | 'delivered' | 'cancelled' | 'rejected_unsafe';

export interface FoodDonation {
  id: string;
  foodName: string;
  category: FoodCategory;
  dietType: FoodDietType;
  quantityServings: number;
  estimatedWeightKg: number;
  numberOfContainers: number;
  description: string;
  prepTime: string; // ISO string or human string
  prepTimeHoursAgo: number;
  availableUntil: string;
  storageCondition: StorageCondition;
  packaging: PackagingType;
  donorId: string;
  donorName: string;
  donorOrg: string;
  donorPhone: string;
  pickupAddress: string;
  pickupLandmark: string;
  pickupCity: string;
  pickupPinCode: string;
  // Status and logistics
  status: DonationStatus;
  createdAt: string;
  isSafetyApproved: boolean;
  safetyScore: number;
  safetyNotes?: string;
  allergenInfo?: string;
  // Matching and fulfillment
  requestedByRecipientId?: string;
  requestedByRecipientName?: string;
  recipientAddress?: string;
  recipientContact?: string;
  assignedVolunteerId?: string;
  assignedVolunteerName?: string;
  assignedVolunteerPhone?: string;
  pickupVerificationCode?: string;
  deliveryVerificationCode?: string;
  pickedUpAt?: string;
  deliveredAt?: string;
  deliveryNotes?: string;
}

export interface RecipientOrg {
  id: string;
  name: string;
  type: 'orphanage' | 'old_age_home' | 'homeless_shelter' | 'community_kitchen';
  capacity: number;
  currentNeed: string;
  dietaryPreference: 'veg' | 'non_veg' | 'all';
  address: string;
  contactPerson: string;
  phone: string;
  distanceKm: number;
  verified: boolean;
}

export interface VolunteerBadge {
  id: string;
  name: string;
  description: string;
  iconName: string;
  unlockedAt?: string;
  pointsRequired?: number;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
}

export interface ImpactStats {
  mealsDelivered: number;
  kgRescued: number;
  completedDeliveries: number;
  activeVolunteers: number;
  careHomesSupported: number;
  co2SavedKg: number;
}
