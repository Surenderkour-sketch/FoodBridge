import React from 'react';
import { UtensilsCrossed, Heart, ShieldCheck, Mail, Phone, ExternalLink } from 'lucide-react';

export const Footer: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-xs">
      {/* Top Banner: Food Safety Assurance */}
      <div className="border-b border-slate-900 bg-slate-900/40 py-4 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3 text-center md:text-left">
          <div className="flex items-center gap-2 text-slate-300">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>
              <strong>Zero Compromise on Food Safety:</strong> All surplus donations pass preparation window verification, packaging inspection, and recipient thermal checks.
            </span>
          </div>
          <button
            onClick={() => onNavigate('safety')}
            className="text-emerald-400 hover:text-emerald-300 font-semibold underline underline-offset-4 flex items-center gap-1 shrink-0"
          >
            <span>View Safety Standards</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Col 1: Brand */}
        <div className="space-y-3 md:col-span-1">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-600 text-white">
              <UtensilsCrossed className="w-4 h-4" />
            </div>
            <span className="font-extrabold text-white text-base tracking-tight">FoodBridge</span>
          </div>
          <p className="text-slate-400 leading-relaxed text-xs">
            Share Food, Save Lives. Bridging surplus meals from marriage halls, hotels, and functions to orphanages and care homes via certified local volunteer runs.
          </p>
          <div className="pt-2 flex items-center gap-2 text-emerald-400 font-medium text-xs">
            <Heart className="w-4 h-4 fill-emerald-400" />
            <span>Rescuing dignity, one plate at a time</span>
          </div>
        </div>

        {/* Col 2: Quick Links */}
        <div className="space-y-2">
          <h4 className="text-white font-semibold text-xs tracking-wider uppercase">Platform Workflow</h4>
          <ul className="space-y-1.5 text-xs">
            <li>
              <button onClick={() => onNavigate('donate')} className="hover:text-white transition">
                Post Surplus Banquet Food
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('available')} className="hover:text-white transition">
                Browse Available Donations
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('volunteer')} className="hover:text-white transition">
                Volunteer Dispatch Hub
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('rewards')} className="hover:text-white transition">
                Volunteer Badges & Points
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('impact')} className="hover:text-white transition">
                Community Impact Analytics
              </button>
            </li>
          </ul>
        </div>

        {/* Col 3: Proposed Medical Benefit Notice */}
        <div className="space-y-2">
          <h4 className="text-amber-400 font-semibold text-xs tracking-wider uppercase">
            Volunteer Wellness Concept
          </h4>
          <div className="p-3 rounded-xl bg-slate-900 border border-amber-500/20 text-slate-300 space-y-1.5">
            <div className="text-[10px] font-bold uppercase text-amber-300">
              [Proposed Sponsor-Funded Program]
            </div>
            <p className="text-[11px] leading-relaxed text-slate-400">
              Future medical checkup benefits for verified volunteers and families are currently in planning. Awaiting corporate CSR sponsorships.
            </p>
            <button
              onClick={() => onNavigate('rewards')}
              className="text-xs text-amber-400 hover:text-amber-300 font-medium inline-block underline"
            >
              Learn about proposed plan & CSR partnership →
            </button>
          </div>
        </div>

        {/* Col 4: Contact & Verification */}
        <div className="space-y-2">
          <h4 className="text-white font-semibold text-xs tracking-wider uppercase">
            Emergency & Food Hotline
          </h4>
          <p className="text-xs text-slate-400">
            Have a bulk wedding surplus right now? Call our 24/7 volunteer rescue coordinator desk:
          </p>
          <div className="flex items-center gap-2 text-white font-semibold text-xs">
            <Phone className="w-4 h-4 text-emerald-400" />
            <span>1800-FOOD-BRIDGE (Toll Free)</span>
          </div>
          <div className="flex items-center gap-2 text-slate-400 text-xs">
            <Mail className="w-4 h-4 text-slate-500" />
            <span>coordinator@foodbridge.org</span>
          </div>
          <div className="pt-2 text-[11px] text-slate-500">
            Strict safety compliance: cooked meals over 4 hours at ambient temperature are flagged unsafe and rejected.
          </div>
        </div>
      </div>

      <div className="border-t border-slate-900 py-4 px-4 text-center text-slate-500 text-[11px]">
        © 2026 FoodBridge. Dedicated to zero hunger and zero food wastage. Open volunteer network.
      </div>
    </footer>
  );
};
