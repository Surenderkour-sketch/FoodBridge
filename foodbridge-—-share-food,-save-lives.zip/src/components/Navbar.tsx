import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import {
  Heart,
  UtensilsCrossed,
  PackagePlus,
  Bike,
  Award,
  BarChart3,
  ShieldAlert,
  Users,
  RotateCcw,
  Menu,
  X,
  ChevronDown,
  Sparkles,
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const { currentUser, users, switchPersona, activeRole, setActiveRole, resetDemoData, donations } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [personaDropdownOpen, setPersonaDropdownOpen] = useState(false);

  const availableDonationsCount = donations.filter((d) => d.status === 'available').length;
  const pendingRequestsCount = donations.filter((d) => d.status === 'requested').length;

  const handleNavClick = (tab: string) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white">
      {/* Top Demo Bar for Judges */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-amber-950 px-4 py-1.5 border-b border-emerald-900/40 text-[11px] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-slate-300">
          <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-medium text-emerald-400">Live Demo Mode Active</span>
          <span className="hidden sm:inline text-slate-400">| Complete food rescue loop ready for testing</span>
        </div>

        {/* Quick Persona Switcher for Judges */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <button
              onClick={() => setPersonaDropdownOpen(!personaDropdownOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800/90 border border-slate-700 hover:border-slate-600 text-slate-200 transition font-medium"
            >
              <Users className="w-3.5 h-3.5 text-amber-400" />
              <span>Persona: <strong className="text-white">{currentUser.name}</strong></span>
              <span className="text-[10px] uppercase px-1.5 py-0.5 rounded bg-emerald-900/60 text-emerald-300 border border-emerald-700/50">
                {currentUser.activeRole}
              </span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {personaDropdownOpen && (
              <div className="absolute right-0 mt-1.5 w-72 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl py-1 z-50 text-xs">
                <div className="px-3 py-1.5 border-b border-slate-800 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Switch Persona (1-Click Test)
                </div>
                {users.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => {
                      switchPersona(u.id);
                      setPersonaDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 flex items-start gap-2 hover:bg-slate-800/80 transition ${
                      currentUser.id === u.id ? 'bg-emerald-950/40 text-emerald-300' : 'text-slate-300'
                    }`}
                  >
                    <div className="w-2 h-2 rounded-full mt-1.5 shrink-0 bg-emerald-400" />
                    <div className="flex-1 truncate">
                      <div className="font-semibold text-slate-200">{u.name}</div>
                      <div className="text-[10px] text-slate-400 truncate">
                        {u.organizationName || u.roles.join(' & ')} • {u.city}
                      </div>
                    </div>
                    <span className="text-[9px] uppercase px-1 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700 shrink-0">
                      {u.roles.join('/')}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={resetDemoData}
            title="Reset to fresh sample data"
            className="flex items-center gap-1 px-2 py-1 rounded-md bg-slate-800/80 hover:bg-rose-950/60 hover:text-rose-300 border border-slate-700 text-slate-300 transition"
          >
            <RotateCcw className="w-3 h-3" />
            <span className="hidden md:inline">Reset Demo</span>
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 shadow-md shadow-emerald-500/20 group-hover:scale-105 transition">
              <UtensilsCrossed className="w-5 h-5 text-white" />
              <Heart className="w-3 h-3 text-rose-300 fill-rose-300 absolute -bottom-0.5 -right-0.5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-emerald-200 bg-clip-text text-transparent">
                  FoodBridge
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  AI
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium tracking-wide hidden sm:block">
                Share Food, Save Lives
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2 text-xs font-semibold">
            <button
              onClick={() => handleNavClick('home')}
              className={`px-3 py-2 rounded-lg transition ${
                activeTab === 'home' ? 'bg-slate-800 text-emerald-400' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              Home
            </button>

            <button
              onClick={() => handleNavClick('available')}
              className={`relative px-3 py-2 rounded-lg transition flex items-center gap-1.5 ${
                activeTab === 'available' ? 'bg-slate-800 text-emerald-400' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <span>Available Food</span>
              {availableDonationsCount > 0 && (
                <span className="px-1.5 py-0.2 text-[10px] rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  {availableDonationsCount}
                </span>
              )}
            </button>

            <button
              onClick={() => handleNavClick('donate')}
              className={`px-3 py-2 rounded-lg transition flex items-center gap-1.5 ${
                activeTab === 'donate' ? 'bg-slate-800 text-emerald-400' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <PackagePlus className="w-3.5 h-3.5 text-emerald-400" />
              <span>Donate Food</span>
            </button>

            <button
              onClick={() => handleNavClick('volunteer')}
              className={`relative px-3 py-2 rounded-lg transition flex items-center gap-1.5 ${
                activeTab === 'volunteer' ? 'bg-slate-800 text-emerald-400' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Bike className="w-3.5 h-3.5 text-amber-400" />
              <span>Volunteer Hub</span>
              {pendingRequestsCount > 0 && (
                <span className="px-1.5 py-0.2 text-[10px] rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                  {pendingRequestsCount} active
                </span>
              )}
            </button>

            <button
              onClick={() => handleNavClick('rewards')}
              className={`px-3 py-2 rounded-lg transition flex items-center gap-1.5 ${
                activeTab === 'rewards' ? 'bg-slate-800 text-emerald-400' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>Badges & Rewards</span>
            </button>

            <button
              onClick={() => handleNavClick('impact')}
              className={`px-3 py-2 rounded-lg transition flex items-center gap-1.5 ${
                activeTab === 'impact' ? 'bg-slate-800 text-emerald-400' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-cyan-400" />
              <span>Impact</span>
            </button>

            <button
              onClick={() => handleNavClick('safety')}
              className={`px-3 py-2 rounded-lg transition flex items-center gap-1.5 ${
                activeTab === 'safety' ? 'bg-slate-800 text-emerald-400' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
              <span>Food Safety</span>
            </button>
          </nav>

          {/* Role Toggle Selector on right */}
          <div className="hidden lg:flex items-center gap-2">
            <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-[11px] font-semibold">
              <button
                onClick={() => setActiveRole('donor')}
                className={`px-2.5 py-1 rounded-lg transition ${
                  activeRole === 'donor'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Donor
              </button>
              <button
                onClick={() => setActiveRole('recipient')}
                className={`px-2.5 py-1 rounded-lg transition ${
                  activeRole === 'recipient'
                    ? 'bg-teal-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Care Home
              </button>
              <button
                onClick={() => setActiveRole('volunteer')}
                className={`px-2.5 py-1 rounded-lg transition ${
                  activeRole === 'volunteer'
                    ? 'bg-amber-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Volunteer
              </button>
            </div>

            <button
              onClick={() => handleNavClick('auth')}
              className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-800/80 hover:bg-slate-800 text-slate-200 transition"
            >
              Register / Log
            </button>
          </div>

          {/* Mobile hamburger */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-800 text-slate-200 hover:text-white focus:outline-none"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-900 border-b border-slate-800 px-4 pt-2 pb-6 space-y-2 text-sm">
          {/* Active role pills on mobile */}
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800 mb-3">
            <span className="text-xs text-slate-400">Current Role:</span>
            <div className="flex gap-1 text-xs">
              {(['donor', 'recipient', 'volunteer'] as UserRole[]).map((r) => (
                <button
                  key={r}
                  onClick={() => setActiveRole(r)}
                  className={`px-2.5 py-1 rounded-lg font-semibold uppercase text-[10px] ${
                    activeRole === r ? 'bg-emerald-600 text-white' : 'text-slate-400 bg-slate-900'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => handleNavClick('home')}
            className="w-full text-left px-3 py-2 rounded-lg text-slate-200 hover:bg-slate-800 flex items-center justify-between"
          >
            <span>Home</span>
          </button>
          <button
            onClick={() => handleNavClick('available')}
            className="w-full text-left px-3 py-2 rounded-lg text-slate-200 hover:bg-slate-800 flex items-center justify-between"
          >
            <span>Available Food</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800">
              {availableDonationsCount} listings
            </span>
          </button>
          <button
            onClick={() => handleNavClick('donate')}
            className="w-full text-left px-3 py-2 rounded-lg text-slate-200 hover:bg-slate-800 flex items-center gap-2"
          >
            <PackagePlus className="w-4 h-4 text-emerald-400" />
            <span>Donate Surplus Food</span>
          </button>
          <button
            onClick={() => handleNavClick('volunteer')}
            className="w-full text-left px-3 py-2 rounded-lg text-slate-200 hover:bg-slate-800 flex items-center justify-between"
          >
            <span className="flex items-center gap-2">
              <Bike className="w-4 h-4 text-amber-400" />
              <span>Volunteer Dashboard</span>
            </span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-amber-950 text-amber-400 border border-amber-800">
              {pendingRequestsCount} active
            </span>
          </button>
          <button
            onClick={() => handleNavClick('rewards')}
            className="w-full text-left px-3 py-2 rounded-lg text-slate-200 hover:bg-slate-800 flex items-center gap-2"
          >
            <Award className="w-4 h-4 text-amber-400" />
            <span>Badges & Leaderboard</span>
          </button>
          <button
            onClick={() => handleNavClick('impact')}
            className="w-full text-left px-3 py-2 rounded-lg text-slate-200 hover:bg-slate-800 flex items-center gap-2"
          >
            <BarChart3 className="w-4 h-4 text-cyan-400" />
            <span>Community Impact</span>
          </button>
          <button
            onClick={() => handleNavClick('safety')}
            className="w-full text-left px-3 py-2 rounded-lg text-slate-200 hover:bg-slate-800 flex items-center gap-2"
          >
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>Food Safety Protocols</span>
          </button>
          <button
            onClick={() => handleNavClick('auth')}
            className="w-full text-left px-3 py-2 rounded-lg text-slate-200 hover:bg-slate-800 flex items-center gap-2"
          >
            <Users className="w-4 h-4 text-slate-400" />
            <span>Register / Switch Persona</span>
          </button>
        </div>
      )}
    </header>
  );
};
