import React from 'react';
import { useApp } from '../context/AppContext';
import { Award, Sparkles, CheckCircle2, HeartHandshake, ShieldCheck, Zap, X, ArrowRight } from 'lucide-react';

export const CelebrationModal: React.FC<{ onNavigateToRewards?: () => void }> = ({ onNavigateToRewards }) => {
  const { awardCelebration, dismissCelebration } = useApp();

  if (!awardCelebration) return null;

  const { volunteerName, badgeAwarded, pointsEarned, mealsDelivered, recipientName } = awardCelebration;

  const getBadgeIcon = (iconName?: string) => {
    switch (iconName) {
      case 'Award':
        return <Award className="w-12 h-12 text-amber-400" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-12 h-12 text-emerald-400" />;
      case 'Zap':
        return <Zap className="w-12 h-12 text-amber-300" />;
      case 'HeartHandshake':
        return <HeartHandshake className="w-12 h-12 text-rose-400" />;
      default:
        return <Sparkles className="w-12 h-12 text-amber-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-gradient-to-b from-slate-900 to-slate-950 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl text-center overflow-hidden">
        {/* Glow decoration */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-48 h-48 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 left-1/2 -translate-x-1/2 w-48 h-48 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

        <button
          onClick={dismissCelebration}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/50 hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 mb-4 animate-bounce">
          <CheckCircle2 className="w-8 h-8" />
        </div>

        <h3 className="text-xs uppercase tracking-widest font-bold text-emerald-400">
          Delivery Handover Verified
        </h3>
        <h2 className="text-2xl font-extrabold text-white mt-1">
          Heroic Mission Accomplished!
        </h2>
        <p className="text-slate-300 text-sm mt-2">
          Thank you <span className="font-semibold text-white">{volunteerName}</span>. You just nourished{' '}
          <span className="font-semibold text-amber-300">{mealsDelivered} souls</span> at{' '}
          <span className="font-semibold text-white">{recipientName}</span>.
        </p>

        {/* Points & Stats pill */}
        <div className="grid grid-cols-2 gap-3 my-6">
          <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80">
            <div className="text-2xl font-black text-amber-400">+{pointsEarned}</div>
            <div className="text-xs text-slate-400 mt-0.5">Points Earned</div>
          </div>
          <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80">
            <div className="text-2xl font-black text-emerald-400">{mealsDelivered}</div>
            <div className="text-xs text-slate-400 mt-0.5">Warm Meals Saved</div>
          </div>
        </div>

        {/* Badge unlock if any */}
        {badgeAwarded && (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-amber-900/30 to-amber-950/40 border border-amber-500/40 text-left mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/40 shrink-0">
                {getBadgeIcon(badgeAwarded.iconName)}
              </div>
              <div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                  New Badge Unlocked!
                </div>
                <div className="font-bold text-white text-base">{badgeAwarded.name}</div>
                <div className="text-xs text-slate-300 mt-0.5">{badgeAwarded.description}</div>
              </div>
            </div>
          </div>
        )}

        <div className="flex flex-col gap-2.5">
          <button
            onClick={() => {
              dismissCelebration();
              if (onNavigateToRewards) onNavigateToRewards();
            }}
            className="w-full py-3 px-4 rounded-xl font-semibold text-sm bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:from-emerald-400 hover:to-teal-400 transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
          >
            <span>View Rewards & Leaderboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={dismissCelebration}
            className="w-full py-2.5 px-4 rounded-xl text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800/50 transition"
          >
            Continue Deliveries
          </button>
        </div>
      </div>
    </div>
  );
};
